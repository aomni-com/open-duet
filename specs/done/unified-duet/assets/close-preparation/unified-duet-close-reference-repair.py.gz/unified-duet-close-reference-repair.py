#!/usr/bin/env python3
"""Prepare or apply navigational repairs around the separately owned git mv.

Run --plan BEFORE moving. After git mv and slice deletion, run --apply BEFORE
replacing the moved root README with the prepared rationale. Never edits JSON,
gzip, logs, images or binary assets. Plan manifests seal every retained asset and
visualization; application checks that none was deleted and frozen bytes match.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path('/Users/synthetic-user/.codex/worktrees/232f/duet')
OLD = ROOT / 'specs/unified-duet'
NEW = ROOT / 'specs/done/unified-duet'
PLAN = Path('/tmp/unified-duet-close-reference-plan.json')
TEXT = {'.md', '.mdx', '.html', '.ts', '.js', '.mjs', '.py', '.sh', '.yml', '.yaml'}
ANCHORS = {
    '00': 'one-complete-runtime', '01': 'one-complete-runtime',
    '02': 'one-login-explicit-workspaces', '03': 'one-login-explicit-workspaces',
    '04': 'computers-and-workspaces-are-different-identities',
    '05': 'one-login-explicit-workspaces', '06': 'one-complete-runtime',
    '07': 'preserve-existing-machines-and-work', '08': 'one-complete-runtime',
    '09': 'alternatives-rejected', '10': 'preserve-existing-machines-and-work',
}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def mapped(path):
    if path.is_relative_to(OLD):
        rel = path.relative_to(OLD)
        if rel.parts and rel.parts[0] == 'slices':
            return NEW / 'README.md'
        return NEW / rel
    return path

def slice_anchor(path):
    if path.is_relative_to(OLD / 'slices'):
        return ANCHORS.get(path.name[:2])
    return None

def rewrite_link(link, old_file, new_file):
    if re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:', link) or link.startswith(('#', '//')):
        return link
    angled = link.startswith('<') and link.endswith('>')
    plain = link[1:-1] if angled else link
    target, sep, fragment = plain.partition('#')
    if not target:
        return link
    # Keep remote and absolute historical links intact, except this exact spec path.
    original = Path(os.path.normpath(str(old_file.parent / target)))
    if target.startswith('/') and not original.is_relative_to(OLD):
        return link
    destination = mapped(original)
    relative = os.path.relpath(destination, new_file.parent)
    anchor = slice_anchor(original)
    if anchor:
        relative += '#' + anchor
    elif sep:
        relative += '#' + fragment
    return '<' + relative + '>' if angled else relative

def proposed(old_file, text):
    new_file = mapped(old_file)
    # Markdown and HTML local navigation are resolved from their PRE-MOVE owner.
    if old_file.suffix in {'.md', '.mdx'}:
        text = re.sub(r'(?<=\]\()([^\s)]+)(?=\))',
                      lambda m: rewrite_link(m.group(1), old_file, new_file), text)
    if old_file.suffix == '.html':
        text = re.sub(r'(?<=href=")([^"]+)(?=")',
                      lambda m: rewrite_link(m.group(1), old_file, new_file), text)
    # Source-bearing probe/test references use explicit repo-root names.
    text = text.replace('specs/unified-duet', 'specs/done/unified-duet')
    if old_file == OLD / 'exploration.md':
        lines = text.splitlines()
        if lines and lines[0].startswith('> Superseded'):
            lines[0] = '> Historical interview and territory record. The [shipped rationale](README.md) and maintained code settle these original questions.'
            text = '\n'.join(lines) + '\n'
    if old_file == OLD / 'research.md':
        text = '> Historical preservation inputs and pre-implementation research; the [shipped rationale](README.md) owns the completed design.\n\n' + text
    if old_file == OLD / 'visualizations/roadmap.html':
        text = text.replace('Implementation plan · 03 October 2026', 'Historical implementation plan · 03 October 2026')
        text = text.replace('Acceptance ladder — see the canonical spec for current progress.', 'Historical acceptance ladder — see the shipped rationale for the completed design.')
        text = text.replace('Canonical spec and next agent prompt ↗', 'Shipped rationale ↗')
        text = re.sub(r'Read slice \d{2} ↗', 'Read rationale ↗', text)
        text = text.replace('Copy implementation request', 'Copy rationale review request')
        text = re.sub(r"const prompt='Implement [^']+';", "const prompt='Review specs/done/unified-duet/README.md and its choices ledger. Retained assets preserve historical evidence; current package READMEs own implementation mechanics.';", text)
    return text

def prepare():
    assert OLD.is_dir() and not NEW.exists(), 'Plan before git mv'
    names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).split(b'\0')
    changes = []
    preserved = []
    deletions = []
    for name in names:
        if not name:
            continue
        path = ROOT / os.fsdecode(name)
        if not path.is_file():
            continue
        if path.is_relative_to(OLD / 'slices'):
            deletions.append(str(path.relative_to(ROOT)))
            continue
        if path.is_relative_to(OLD / 'assets') or path.is_relative_to(OLD / 'visualizations'):
            preserved.append({'path': str(mapped(path).relative_to(ROOT)),
                              'sha256': digest(path),
                              'frozen': path.suffix not in TEXT})
        if path.suffix not in TEXT:
            continue
        text = path.read_text()
        # Other specs are historical; only exact incoming references need changes.
        if not path.is_relative_to(OLD) and 'specs/unified-duet' not in text:
            continue
        result = proposed(path, text)
        if result != text:
            changes.append({'oldPath': str(path.relative_to(ROOT)),
                            'newPath': str(mapped(path).relative_to(ROOT)),
                            'beforeSha256': digest(path),
                            'content': result})
    plan = {'root': str(ROOT), 'changes': changes, 'preserved': preserved,
            'deleteOnly': deletions,
            'ordering': ['git mv specs/unified-duet specs/done/unified-duet',
                         'git rm -r specs/done/unified-duet/slices',
                         'python3 /tmp/unified-duet-close-reference-repair.py --apply',
                         'copy /tmp/unified-duet-final-closed-readme.md over moved README.md',
                         'repair remaining stale historical prose manually and run local link audit']}
    PLAN.write_text(json.dumps(plan, indent=2) + '\n')
    print(json.dumps({'plan': str(PLAN), 'changes': len(changes),
                      'preservedAssetsAndVisualizations': len(preserved),
                      'deleteOnly': len(deletions),
                      'changedPaths': [c['newPath'] for c in changes]}, indent=2))

def apply():
    plan = json.loads(PLAN.read_text())
    assert not OLD.exists() and NEW.is_dir(), 'Apply only after git mv'
    assert not (NEW / 'slices').exists(), 'Delete only planned slices first'
    # Validate all preconditions before the first write.
    for change in plan['changes']:
        path = ROOT / change['newPath']
        assert digest(path) == change['beforeSha256'], 'Changed since plan: ' + str(path)
    for item in plan['preserved']:
        path = ROOT / item['path']
        assert path.is_file(), 'Retained evidence missing: ' + str(path)
        if item['frozen']:
            assert digest(path) == item['sha256'], 'Frozen bytes changed: ' + str(path)
    for change in plan['changes']:
        (ROOT / change['newPath']).write_text(change['content'])
    for item in plan['preserved']:
        path = ROOT / item['path']
        assert path.is_file()
        if item['frozen']:
            assert digest(path) == item['sha256']
    print(json.dumps({'applied': len(plan['changes']), 'frozenBytesVerified': True}))

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--plan', action='store_true')
parser.add_argument('--apply', action='store_true')
args = parser.parse_args()
assert args.plan != args.apply, 'Choose exactly one of --plan or --apply'
prepare() if args.plan else apply()
