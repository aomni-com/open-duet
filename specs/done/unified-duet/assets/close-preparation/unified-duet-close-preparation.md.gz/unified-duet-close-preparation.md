# Close-spec preparation

Prepared rationale: `/tmp/unified-duet-final-closed-readme.md` (1,220 words, 18 projected local links; targets exist).

Reference repair tool: `/tmp/unified-duet-close-reference-repair.py`.
Plan/inventory: `/tmp/unified-duet-close-reference-plan.json`.
Current plan changes 26 navigational/source-reference files and deletes only the 11 slice files.
It inventories all 1204 currently tracked assets and visualization files; 1113 frozen/binary/log files have sealed bytes.
JSON, gzip, images and logs are never rewritten. Existing evidence is retained, not reauthored.
Run --plan again immediately before archival, after banking final release evidence, so it includes new tracked files and current doc hashes.
The --apply command deliberately fails before any write if a tracked target changed since planning, a retained asset disappeared, or frozen bytes changed.

Required application order is in the JSON plan: git mv, git rm only slices, repair --apply, then replace the moved root README with the prepared rationale. Copying the rationale first would make the plan checksum fail and its already-rebased links unsuitable for old-path rebasing.
The tool rewrites local Markdown/HTML navigation and repo-root references in operative scripts/tests. Incoming owners include web/agent/backend READMEs, image verifier, and public package test. Archive Markdown links to deleted slices point at the relevant rationale section. Research/exploration/roadmap get explicit historical framing; the roadmap remains retained and navigable but its copy button requests rationale review, not reimplementation.

## Durable material added beyond the root draft

- Named human keys stay separately revocable; app/OAuth boundaries are preserved.
- Old pending grant approvals expire while issued human hashes/identities survive.
- Local/remote selection remains distinct from target/default billing; admitted generations settle to their recorded workspace.
- Explicit machine reactivation and immutable account/API/machine reconcile snapshots explain why retry cannot undo removal or mix accounts.
- Final Mac files AND engine state use normalized API location + durable workspace ID; slug/key/machine changes do not define storage. Opaque defaults are disclosed, status owns discovery, explicit foreground directories retain the intentional escape hatch.
- Native memory/image assets and destination permissions are part of complete runtime integrity; external Bun and VM compiled payload remain different distribution surfaces.
- First-adoption recovery restores wiring, never stale mutable customer state, and closes when new work can be admitted. Complete certified current/previous pairs explain the second ordinary activation.
- Source preservation, runtime separation and preview/backend ownership remain durable boundaries.
- Final sync-guide before/candidate captures, actual production route/layout target, viewport/endings/crops and evidence limits now have a visual provenance trail.

## Limits

This is preparation only. No ROOT file was edited, moved or deleted, and no commit or external operation was performed.
The rationale claims the implemented design and completed VM migration; it does not claim the cold registry installs, duetfs deprecation or old publisher retirement are complete.
The source concern from a concatenated read was withdrawn: createHash is imported at the end of daemon-status.ts, and no source repair is needed.
Root must still run the close-spec unbiased claim audit on the actually installed rationale and verify all remaining release receipts before calling the archive complete.
