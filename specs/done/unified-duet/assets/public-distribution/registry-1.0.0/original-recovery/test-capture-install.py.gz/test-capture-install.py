import json
from pathlib import Path
import subprocess
import tarfile
import tempfile
import unittest

SCRIPT = Path(__file__).with_name('capture-install.py')
EVIDENCE = Path('/tmp/unified-duet-registry-final-261004/original-recovery')

class RecoveredCapture(unittest.TestCase):
    def setUp(self):
        self.scratch = tempfile.TemporaryDirectory(prefix='duet-recovered-capture-test-')
        self.directory = Path(self.scratch.name)
        base = self.directory/'installed/node_modules'
        package = base/'@duetso/agent'
        package.mkdir(parents=True)
        with tarfile.open(EVIDENCE/'registry-agent-1.0.0.tgz') as archive:
            for name in ['package.json', 'dist/cli-entry.js']:
                target = package/name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.extractfile('package/'+name).read())
        manifest = json.loads((package/'package.json').read_text())
        receipt = json.loads((EVIDENCE/'recovered-verification.json').read_text())
        for name in ['@opentui/core-linux-x64', '@vscode/ripgrep-linux-x64',
                     '@opentui/core', '@vscode/ripgrep', '@electric-sql/pglite',
                     '@silvia-odwyer/photon-node', '@mariozechner/clipboard']:
            owner = base/name
            owner.mkdir(parents=True, exist_ok=True)
            version = manifest.get('dependencies', {}).get(name) or manifest.get('optionalDependencies', {}).get(name) or '0.0.0'
            (owner/'package.json').write_text(json.dumps({'name':name,'version':version}))
        (base/'.bin').mkdir()
        (base/'.bin/duet').symlink_to(package/'dist/cli-entry.js')
        (self.directory/'installed/package-lock.json').write_text(json.dumps({'packages':{'node_modules/@duetso/agent':{'integrity':receipt['artifact']['integrity'],'version':'1.0.0','resolved':receipt['registry']['tarball']}}}))

    def tearDown(self):
        self.scratch.cleanup()

    def capture(self, receipt=EVIDENCE/'recovered-verification.json', run=EVIDENCE.parent/'publication-run-initial.json'):
        return subprocess.run(['python3',str(SCRIPT),str(receipt),str(run),str(EVIDENCE/'registry-version.json'),str(EVIDENCE/'registry-agent-1.0.0.tgz'),str(self.directory/'installed'),'linux','x64',str(self.directory/'capture.json')], capture_output=True, text=True)

    def test_accepts_verified_recovery_without_relabeling_failed_workflow(self):
        result = self.capture()
        self.assertEqual(result.returncode, 0, result.stderr)
        output = json.loads((self.directory/'capture.json').read_text())
        self.assertEqual(output['publicationEvidenceStatus'], 'recovered-verification')
        self.assertEqual(output['publicationRunConclusion'], 'failure')
        self.assertEqual(output['publicationRevision'], 'da3779eb8e153a57c6f7e7f4d28ff7c75afd336a')

    def test_rejects_recovered_claim_when_complete_rebuilt_tarball_differs(self):
        receipt = json.loads((EVIDENCE/'recovered-verification.json').read_text())
        receipt['evidence'] = {key:str(EVIDENCE/path) for key,path in receipt['evidence'].items()}
        corrupted = self.directory/'corrupted-original.tgz'
        data = bytearray((EVIDENCE/'rebuilt/duetso-agent-1.0.0.tgz').read_bytes())
        data[-1] ^= 1
        corrupted.write_bytes(data)
        receipt['evidence']['reconstructedTarball'] = str(corrupted)
        changed = self.directory/'recovery.json'
        changed.write_text(json.dumps(receipt))
        result = self.capture(receipt=changed)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('Rebuilt original tarball differs from registry tarball', result.stderr)

    def test_rejects_recovery_when_original_failure_is_rewritten_as_success(self):
        run = json.loads((EVIDENCE.parent/'publication-run-initial.json').read_text())
        run['conclusion'] = 'success'
        changed = self.directory/'rewritten-run.json'
        changed.write_text(json.dumps(run))
        result = self.capture(run=changed)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("assert run['conclusion'] == 'failure'", result.stderr)

    def test_accepts_npm_prefix_lock_key_with_same_registry_version_and_integrity(self):
        path = self.directory/'installed/package-lock.json'
        lock = json.loads(path.read_text())
        item = lock['packages'].pop('node_modules/@duetso/agent')
        lock['packages']['../../scratch/install/node_modules/@duetso/agent'] = item
        path.write_text(json.dumps(lock))
        result = self.capture()
        self.assertEqual(result.returncode, 0, result.stderr)

if __name__ == '__main__': unittest.main()


