"""Public metadata only; run after publication verification and cold installation."""
import base64
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile

receipt_path, run_path, metadata_path, tarball_path, install_path, platform, arch, output = sys.argv[1:]
receipt = json.loads(Path(receipt_path).read_text())
run = json.loads(Path(run_path).read_text())
metadata = json.loads(Path(metadata_path).read_text())
assert receipt['package'] == '@duetso/agent@1.0.0'
assert receipt['version'] == '1.0.0'
assert run['repository']['full_name'] == 'aomni-com/duet'
assert run['head_branch'] == 'main' and run['event'] == 'push'
assert run['path'] == '.github/workflows/public-cli-release.yml'
if receipt['status'] == 'published':
    assert receipt['registryInstallVerified'] is True
    assert run['conclusion'] == 'success'
    revision = receipt['revision']
    assert receipt['deployment']['revision'] == revision
    assert receipt['deployment']['backend']['revision'] == revision
    assert receipt['deployment']['backend']['schema'] == 1
elif receipt['status'] == 'recovered-verification':
    assert run['conclusion'] == 'failure'
    original = receipt['originalWorkflow']
    assert original['conclusion'] == 'failure' and original['receiptAvailable'] is False
    assert original['runId'] == run['id'] and original['attempt'] == run['run_attempt'] == 1
    assert original['url'] == run['html_url']
    revision = receipt['source']['revision']
    evidence = Path(receipt_path).resolve().parent
    paths = {name: evidence / path for name, path in receipt['evidence'].items()}
    assert json.loads(paths['originalArtifacts'].read_text())['total_count'] == 0
    original_log = paths['originalRunLog'].read_text()
    build_log = paths['reconstructionLog'].read_text()
    tools = receipt['reconstruction']
    assert tools['bun'] == '1.3.14+0d9b296af'
    assert tools['node'] == metadata['_nodeVersion'] == '24.21.0'
    assert tools['npm'] == metadata['_npmVersion'] == '11.19.0'
    assert tools['bun'] in original_log and tools['bun'] in build_log
    assert 'node: v'+tools['node'] in original_log and 'v'+tools['node'] in build_log.splitlines()
    assert 'npm: '+tools['npm'] in original_log and tools['npm'] in build_log.splitlines()
    assert 'bun install --frozen-lockfile --filter @repo/agent --filter @duetso/agent' in original_log
    ready = original['productionReadinessLog']
    assert ready['apiRevision'] == ready['backendRevision'] == revision
    assert ready['observedAt'] in original_log
    assert f'readiness api={revision} backend={revision}' in original_log
    assert 'No match found for version 1.0.0' in original_log
    source_bytes = paths['sourceArchive'].read_bytes()
    assert hashlib.sha256(source_bytes).hexdigest() == receipt['source']['gitArchiveSha256']
    with tarfile.open(paths['sourceArchive']) as frozen:
        assert frozen.pax_headers['comment'] == revision
        for name, expected in receipt['source']['inputSha256'].items():
            assert hashlib.sha256(frozen.extractfile(name).read()).hexdigest() == expected
        contract = frozen.extractfile('packages/contract/src/deployment/index.ts').read()
        publisher = frozen.extractfile('packages/duet/scripts/release-public-cli.ts').read()
        assert b'export const BACKEND_SCHEMA_VERSION = 1' in contract
        assert b'deployment.backend.schema === BACKEND_SCHEMA_VERSION' in publisher
    node_bytes = paths['nodeDistribution'].read_bytes()
    node_sha = hashlib.sha256(node_bytes).hexdigest()
    assert node_sha == tools['nodeDistributionSha256']
    assert f"{node_sha}  {paths['nodeDistribution'].name}" in paths['nodeChecksums'].read_text()
    reconstructed = paths['reconstructedTarball'].read_bytes()
    assert reconstructed == Path(tarball_path).read_bytes(), 'Rebuilt original tarball differs from registry tarball'
    assert 'sha512-' + base64.b64encode(hashlib.sha512(reconstructed).digest()).decode() == receipt['registry']['integrity']
    packument = json.loads(paths['registryPackument'].read_text())
    assert packument['time']['1.0.0'] == receipt['registry']['publishedAt']
    assert packument['versions']['1.0.0']['dist']['integrity'] == receipt['artifact']['integrity']
    assert receipt['externalWritesPerformed'] is False
else:
    raise AssertionError('Unsupported publication evidence status')
assert run['head_sha'] == revision
assert metadata['name'] == '@duetso/agent' and metadata['version'] == '1.0.0'
assert metadata['bin'] == {'duet': 'dist/cli-entry.js'}
integrity = receipt['artifact']['integrity']
assert metadata['dist']['integrity'] == integrity
tarball = Path(tarball_path).read_bytes()
assert 'sha512-' + base64.b64encode(hashlib.sha512(tarball).digest()).decode() == integrity
assert hashlib.sha256(tarball).hexdigest() == receipt['artifact']['sha256']
assert len(tarball) == receipt['artifact']['bytes']
with tarfile.open(tarball_path, 'r:gz') as archive:
    packed_manifest = json.load(archive.extractfile('package/package.json'))
    packed_entry = archive.extractfile('package/dist/cli-entry.js').read()
base = Path(install_path) / 'node_modules'
package = base / '@duetso/agent'
manifest = json.loads((package / 'package.json').read_text())
assert manifest == packed_manifest
assert (package / 'dist/cli-entry.js').read_bytes() == packed_entry
assert packed_entry.startswith(b'#!/usr/bin/env bun')
lock = json.loads((Path(install_path) / 'package-lock.json').read_text())
public_locks = [(key, value) for key, value in lock['packages'].items()
                if key.endswith('node_modules/@duetso/agent')]
assert len(public_locks) == 1, 'Expected one public CLI registry lock record'
lock_key, public_lock = public_locks[0]
assert public_lock['integrity'] == integrity
assert public_lock['version'] == metadata['version']
assert public_lock['resolved'] == metadata['dist']['tarball']
assert (base / '.bin/duet').resolve() == (package / 'dist/cli-entry.js').resolve()
names = [f'@opentui/core-{platform}-{arch}', f'@vscode/ripgrep-{platform}-{arch}',
         '@opentui/core', '@vscode/ripgrep', '@electric-sql/pglite',
         '@silvia-odwyer/photon-node', '@mariozechner/clipboard']
if platform == 'darwin': names.append(f'@duetso/syncthing-darwin-{arch}')
dependencies = []
for name in names:
    directory = base / name
    item = json.loads((directory / 'package.json').read_text())
    assert item['name'] == name
    if item.get('os'): assert platform in item['os']
    if item.get('cpu'): assert arch in item['cpu']
    expected = manifest.get('dependencies', {}).get(name) or manifest.get('optionalDependencies', {}).get(name)
    if expected: assert item['version'] == expected
    row = {'name': item['name'], 'version': item['version'], 'os': item.get('os'),
           'cpu': item.get('cpu'), 'files': []}
    for file in sorted(directory.rglob('*')):
        if file.is_file() and (file.suffix in ['.so', '.dylib', '.node', '.wasm']
                               or file.name in ['rg', 'syncthing', 'pglite.data', 'vector.tar.gz']):
            data = file.read_bytes()
            row['files'].append({'path': str(file.relative_to(base)),
              'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
              'mode': oct(file.stat().st_mode & 0o777),
              'fileDescription': subprocess.run(['/usr/bin/file', '-b', str(file)],
                   check=True, capture_output=True, text=True).stdout.strip()})
    dependencies.append(row)
Path(output).write_text(json.dumps({
    'status': 'registry bytes and installed closure verified; smoke results recorded separately',
    'publicationRunUrl': run['html_url'], 'publicationRevision': revision,
    'publicationEvidenceStatus': receipt['status'], 'publicationRunConclusion': run['conclusion'],
    'publicationEvidenceReceipt': str(Path(receipt_path).resolve()),
    'publicationEvidenceLimitations': receipt.get('limitations', []),
    'registryPublishedAt': receipt.get('registry', {}).get('publishedAt'),
    'registryIntegrity': integrity, 'packageTarSha256': receipt['artifact']['sha256'],
    'entrySha256': hashlib.sha256(packed_entry).hexdigest(),
    'registryLockKey': lock_key,
    'platform': platform, 'arch': arch, 'dependencies': dependencies,
    'install': str(Path(install_path).resolve()),
}, indent=2) + '\n')
