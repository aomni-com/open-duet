#!/bin/bash
set -euo pipefail
tar -xzf /evidence/node-v24.21.0-linux-x64.tar.gz -C /opt
export PATH=/opt/node-v24.21.0-linux-x64/bin:$PATH
mkdir -p /home/synthetic-user/work/duet/duet
cd /home/synthetic-user/work/duet/duet
tar -xf /evidence/source-da3779eb8.tar
node --version
npm --version
bun --revision
mkdir -p /tmp/bun-original-recovery
bun install --frozen-lockfile --filter @repo/agent --filter @duetso/agent
bun run --cwd packages/agent build
bun packages/duet/scripts/build-public-package.ts
mkdir -p /evidence/rebuilt
cp packages/duet/dist/public-package/package.json /evidence/rebuilt/package.json
cp packages/duet/dist/public-package/dist/cli-entry.js /evidence/rebuilt/cli-entry.js
cd packages/duet/dist/public-package
npm pack --json --ignore-scripts --pack-destination /evidence/rebuilt > /evidence/rebuilt/npm-pack.json
