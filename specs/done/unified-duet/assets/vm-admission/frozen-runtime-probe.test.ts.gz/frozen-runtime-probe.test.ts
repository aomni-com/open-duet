test('07 recon frozen durable acceptance', async () => {
  const { createAgentSessionLedger } = await import('./agent-sessions/ledger')
  const { cp } = await import('node:fs/promises')
  if (process.env.DUET_FREEZE_CHILD === '1') {
    let releaseTrain!: () => void
    const training = new Promise<void>(resolve => { releaseTrain = resolve })
    const runner = new MockAgentRunner()
    let end!: () => void
    const ending = new Promise<void>(resolve => { end = resolve })
    const runtime = await registeredRuntime({
      apiUrl: 'http://controlled-backup',
      fetch: async () => new Promise<Response>(() => {}),
      agentRunnerFactory: () => runner,
      agentRelayEvent: async () => undefined,
      trainRunner: async input => { await training; await writeFakeTrainOutput(input); return { record: null, stdout: '', stderr: '' } },
    })
    const server = Bun.serve({ hostname: '192.0.2.1', port: 0, fetch: request => {
      if (new URL(request.url).pathname === '/probe-release') {
        releaseTrain(); runner.emitEvent({ type: 'complete', state: COMPLETED_TURN_STATE }); end(); return Response.json({ released: true })
      }
      return runtime.app.fetch(request)
    } })
    await writeFile(process.env.DUET_FREEZE_READY!, JSON.stringify({ pid: process.pid, stateDir: join(tempDir, '.duet'), port: server.port }))
    await ending
    await server.stop(true)
    return
  }
  const readyPath = join(tempDir, 'ready.json')
  const child = Bun.spawn([process.execPath, 'test', import.meta.path, '-t', '07 recon frozen durable acceptance', '--timeout', '20000'], {
    env: { ...process.env, DUET_FREEZE_CHILD: '1', DUET_FREEZE_READY: readyPath }, stdout: 'pipe', stderr: 'pipe'
  })
  const stderr = new Response(child.stderr).text()
  let stopped = false
  try {
    await waitForAsync(async () => { try { await readFile(readyPath); return true } catch { return false } })
    const ready = JSON.parse(await readFile(readyPath, 'utf8'))
    const base = `http://192.0.2.1:${ready.port}`
    const post = (path: string, body: unknown) => fetch(base + path, { method: 'POST', headers: jsonAuthHeaders(), body: JSON.stringify(body) })
    expect((await post('/v1/agent/sessions/session_freeze/input', runnerInputBody({ sessionId: 'session_freeze', prompt: 'accepted live turn', behavior: 'steer', tier: 'balanced' }))).status).toBe(200)
    const train = await post('/v1/train', { files: [{ filename: 'first.md', content: 'accepted training' }] })
    expect(train.status).toBe(202)
    const trainId = (await train.json()).jobId
    expect((await post('/v1/backups/probe-backup/start', { attemptId: 'probe-attempt' })).status).toBe(202)
    process.kill(child.pid, 'SIGSTOP'); stopped = true
    await waitForAsync(async () => (await readFile(`/proc/${child.pid}/status`, 'utf8')).includes('State:\tT'))
    const threads = await (await import('node:fs/promises')).readdir(`/proc/${child.pid}/task`)
    const threadStates = await Promise.all(threads.map(async id => (await readFile(`/proc/${child.pid}/task/${id}/status`, 'utf8')).match(/State:\s+([^\n]+)/)?.[1]))
    expect(threadStates.every(state => state?.startsWith('T'))).toBe(true)
    const copy = join(tempDir, 'census')
    await cp(ready.stateDir, copy, { recursive: true })
    const ledger = await createAgentSessionLedger({ stateDir: copy, now: Date.now }).loadAll()
    expect(ledger.corrupt).toEqual([])
    expect(ledger.sessions[0].inFlightCommands.length).toBe(1)
    const jobs = JSON.parse(await readFile(join(copy, 'train/job-ledger-v3.json'), 'utf8'))
    expect(jobs.jobs[trainId].phase).toBe('training')
    const backup = JSON.parse(await readFile(join(copy, 'backups/worker.json'), 'utf8'))
    expect(backup.state).toBe('capturing')
    let newRequestSettled = false
    const fresh = post('/v1/train', { files: [{ filename: 'later.md', content: 'cannot enter while frozen' }] }).then(response => { newRequestSettled = true; return response })
    await Bun.sleep(150)
    expect(newRequestSettled).toBe(false)
    expect(JSON.parse(await readFile(join(ready.stateDir, 'train/job-ledger-v3.json'), 'utf8')).jobs).toEqual(jobs.jobs)
    process.kill(child.pid, 'SIGCONT'); stopped = false
    expect((await fresh).status).toBe(202)
    await fetch(base + '/probe-release').catch(() => undefined)
    expect(await child.exited).toBe(0)
    console.log(JSON.stringify({ sourceRevision: '0f997d60', allMainThreadsStopped: true, frozenAgentCommands: ledger.sessions[0].inFlightCommands.length, frozenTrainPhase: jobs.jobs[trainId].phase, frozenBackupPhase: backup.state, newTrainDeferredUntilResume: true }))
  } finally {
    if (stopped) process.kill(child.pid, 'SIGCONT')
    child.kill(); await child.exited
    const text = await stderr; if (child.exitCode !== 0) console.error(text)
  }
})
