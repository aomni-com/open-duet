test('07 recon Train before-spawn admission is durable', async () => {
  const stateDir = join(root, '.duet'), driveDir = join(root, 'drive')
  const trainDir = join(stateDir, 'train')
  await Promise.all([mkdir(trainDir, { recursive: true }), mkdir(driveDir, { recursive: true })])
  const uploads = createUploadsStore({ uploadsDir: join(trainDir, 'uploads'), tempDir: join(trainDir, 'temp'), capBytes: 1024 * 1024, maxFiles: 200 })
  let release!: () => void, entered!: () => void
  const held = new Promise<void>(resolve => { release = resolve })
  const reached = new Promise<void>(resolve => { entered = resolve })
  const original = uploads.snapshotMove.bind(uploads)
  uploads.snapshotMove = async target => { entered(); await held; return original(target) }
  const ledger = createTrainJobLedger({ stateDir, now: Date.now })
  let runnerStarts = 0
  const routes = createTrainRoutes({ stateDir, driveDir, ...rootTrainRouteOptions(stateDir, driveDir, uploads), jobLedger: ledger, runner: async () => { runnerStarts++; throw new Error('controlled terminal runner') } })
  const request = routes.request('/', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ files: [{ filename: 'note.md', content: 'accepted before child process' }] }) })
  await reached
  const persisted = JSON.parse(await readFile(join(stateDir, 'train/job-ledger-v3.json'), 'utf8'))
  const jobs = Object.values(persisted.jobs) as { phase: string; childPid?: number }[]
  expect(jobs.length).toBe(1)
  expect(jobs[0].phase).toBe('snapshotting')
  expect(jobs[0].childPid).toBeUndefined()
  expect(runnerStarts).toBe(0)
  expect(ledger.hasRunningJob()).toBe(true)
  release()
  expect((await request).status).toBe(202)
  for (let i = 0; i < 100 && ledger.hasRunningJob(); i++) await Bun.sleep(10)
  expect(runnerStarts).toBe(1)
  expect(ledger.hasRunningJob()).toBe(false)
  console.log(JSON.stringify({ sourceRevision: '0f997d60', beforeSpawnDurablePhase: jobs[0].phase, childPidAbsent: true, productionBusyPredicate: true }))
})
