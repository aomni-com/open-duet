import ast,concurrent.futures,datetime,gzip,hashlib,json,pathlib,subprocess,sys
out=pathlib.Path(__file__).parent
repo=pathlib.Path('/Users/synthetic-user/.codex/worktrees/232f/duet')
producer=pathlib.Path('/tmp/unified-duet-background-preservation-audit.py')
tree=ast.parse(producer.read_text())
remote=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='remote' for t in n.targets))
census=json.loads((out/'census.json').read_text())
rows={r['vmName']:r for r in census['items']}
refs=sorted((repo/'specs/unified-duet/assets/release-integration/production-r2').glob('*background-after.json.gz'))
assert len(refs)==5
(out/'background').mkdir()
def inspect(ref):
 raw=ref.read_bytes();old=json.loads(gzip.decompress(raw));row=rows[old['vmName']]
 code=remote.replace('EXPECTED',repr({'bootId':old['bootId'],'processes':old['processes']}))
 child=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15',row['sshDest'],'sudo -n python3 -'],input=code,text=True,capture_output=True,timeout=60)
 if child.returncode:
  (out/'background'/(row['vmName']+'-error.txt')).write_text(child.stderr)
  raise RuntimeError(row['vmName']+' process preservation observation failed')
 value=json.loads(child.stdout)
 for name in ['duet-syncthing.service','duet-desktop.service','duet-desktop-browser.service']:
  before=old['services'][name];now=value['services'][name]
  assert before['MainPID']==now['MainPID'],name+' PID changed'
  if before.get('mainIdentity'):
   assert all(before['mainIdentity'][k]==now['mainIdentity'][k] for k in ['pid','startedTicks','cgroups']),name+' identity changed'
 value.update({'vmName':row['vmName'],'workspaceId':row['workspaceId'],'originalReference':str(ref),'originalReferenceSha256':hashlib.sha256(raw).hexdigest(),'remoteProducerSha256':hashlib.sha256(code.encode()).hexdigest(),'servicesPreserved':True})
 (out/'background'/(row['vmName']+'.json')).write_text(json.dumps(value,indent=2)+'\n')
 print(json.dumps({'vmName':row['vmName'],'processesPreserved':len(value['processes']),'bootPreserved':True,'servicesPreserved':True}),flush=True)
 return value
with concurrent.futures.ThreadPoolExecutor(max_workers=1)as pool:results=list(pool.map(inspect,refs))
(out/'background'/'summary.json').write_text(json.dumps({'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rows':results,'processesPreserved':sum(len(r['processes'])for r in results)},indent=2)+'\n')
