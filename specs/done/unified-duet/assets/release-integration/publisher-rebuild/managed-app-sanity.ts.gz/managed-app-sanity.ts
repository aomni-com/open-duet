import {createHash} from 'node:crypto'
import {existsSync} from 'node:fs'
import {ConvexHttpClient} from '/Users/synthetic-user/.codex/worktrees/232f/duet/node_modules/convex/browser'
import {makeFunctionReference} from '/Users/synthetic-user/.codex/worktrees/232f/duet/node_modules/convex/server'
import {convexUrlsFromDeployment} from '/Users/synthetic-user/.codex/worktrees/232f/duet/packages/contract/src/convex/index.ts'
import {GatewayClient} from '/Users/synthetic-user/.codex/worktrees/232f/duet/apps/api/src/gateway/client.ts'
const assertMigrationEnvironment=(environment:string,origin:string|undefined)=>{if(environment!=='production'||origin!=='https://service.example.invalid')throw new Error('Explicit production origin required')}
const [environment,revision,phase,output,vm]=process.argv.slice(2)
if(environment!=='production'||!/^[a-f0-9]{40}$/.test(revision??'')||!['before','after'].includes(phase??'')||!output?.startsWith('/tmp/')||existsSync(output))throw new Error('Explicit production/revision/phase/new receipt required')
assertMigrationEnvironment('production',process.env.DUET_API_URL)
const client=new ConvexHttpClient(convexUrlsFromDeployment(process.env.CONVEX_DEPLOYMENT!).cloudUrl);client.setAdminAuth(process.env.CONVEX_DEPLOY_KEY!)
const identity=()=>client.query(makeFunctionReference('deployment:identity'))
const beforeIdentity=await identity();if(beforeIdentity.revision!==revision)throw new Error('Backend changed')
const original=await Bun.file('/tmp/unified-duet-runtime-delta.qZuQ0F/census.json').json()
if(original.environment!=='production'||original.revision!==revision)throw new Error('Fresh matching inventory required')
let rows=original.items
if(vm&&vm!=='all')rows=rows.filter((row:any)=>row.vmName===vm)
if(!rows.length)throw new Error('No matching attachment')
const gateway=new GatewayClient({convex:client,internalKey:process.env.DUET_API_INTERNAL_KEY!,now:Date.now,fetchImpl:(url,init)=>fetch(url,{...init,signal:AbortSignal.timeout(60_000)})})
const results=[]
for(const row of rows){
 const apps=await client.query(makeFunctionReference('domains/apps/model:runConfigForWorkspace'),{internalKey:process.env.DUET_API_INTERNAL_KEY,workspaceId:row.workspaceId})
 const configs=apps.map((app:any)=>({appId:app.appId,slug:app.slug,port:app.port,configSha256:createHash('sha256').update(JSON.stringify(app)).digest('hex')}))
 let readyCheck:any=null
 if(phase==='after'){
  const started=Date.now()
  try{const check=await gateway.pushAppsReconcile(row.slug,row.workspaceId,{requiredReadySlugs:apps.map((app:any)=>app.slug)});readyCheck={ok:check.ok,httpStatus:check.ok?200:check.response.status,elapsedMs:Date.now()-started};if(!check.ok)await check.response.body?.cancel()}
  catch{readyCheck={ok:false,transportObservationFailed:true,elapsedMs:Date.now()-started}}
 }
 const program='import json,socket\napps='+JSON.stringify(configs)+'\nresult=[]\nfor app in apps:\n try:\n  with socket.create_connection(("192.0.2.1",app["port"]),timeout=1):pass\n  ready=True\n except OSError:ready=False\n result.append({"appId":app["appId"],"port":app["port"],"tcpAccepting":ready})\nprint(json.dumps(result))\n'
 const child=Bun.spawn(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15',row.sshDest,'python3 -'],{stdin:new TextEncoder().encode(program),stdout:'pipe',stderr:'pipe'})
 const timer=setTimeout(()=>child.kill(),45_000)
 const [text,_error,code]=await Promise.all([new Response(child.stdout).text(),new Response(child.stderr).text(),child.exited]);clearTimeout(timer)
 if(code!==0)throw new Error('Read-only app socket observation failed')
 const ports=JSON.parse(text)
 const result={vmName:row.vmName,workspaceId:row.workspaceId,observedAt:new Date().toISOString(),configs,ports,readyCheck}
 results.push(result);console.log(JSON.stringify({vmName:row.vmName,apps:configs.length,acceptingPorts:ports.filter((p:any)=>p.tcpAccepting).length,readyCheck}))
}
const afterIdentity=await identity();if(afterIdentity.revision!==revision)throw new Error('Backend changed')
await Bun.write(output,JSON.stringify({environment,backendRevision:revision,phase,observedAt:new Date().toISOString(),rows:results,scope:'Existing AppSupervisor fresh required-ready check and TCP sanity; no app commands/config/key values exported'},null,2)+'\n')
if(phase==='after'&&results.some((row:any)=>!row.readyCheck.ok||row.ports.some((p:any)=>!p.tcpAccepting)))process.exitCode=1
