import concurrent.futures, datetime, hashlib, json, pathlib, subprocess, sys
out=pathlib.Path(sys.argv[1]);out.mkdir(exist_ok=False)
inputs=sys.argv[2:];assert inputs
source=pathlib.Path('/tmp/unified-duet-read-main-runtime.py').read_text()
rows=[]
for file in inputs:
 doc=json.loads(pathlib.Path(file).read_text())
 for row in doc['items']:rows.append(dict(row,environment=doc['environment']))
assert len({r['vmName'] for r in rows})==len(rows)
results=[]
def inspect(row):
 child=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15',row['sshDest'],'DUET_NO_AUTO_UPGRADE=1 python3 -'],input=source,text=True,capture_output=True,timeout=90)
 if child.returncode:raise RuntimeError('Read-only VM observation failed: '+row['vmName'])
 observed=json.loads(child.stdout)
 value={'environment':row['environment'],'workspaceId':row['workspaceId'],'slug':row['slug'],'vmName':row['vmName'],'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'observation':observed}
 (out/(row['vmName']+'.json')).write_text(json.dumps(value,indent=2)+'\n')
 return value
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:
 for value in pool.map(inspect,rows):
  results.append(value);o=value['observation'];print(json.dumps({'vmName':value['vmName'],'current':o['manifest']['version'],'previous':o['previousManifest']['version'],'certified':o['bootHealthCertified'],'gatewayPid':o['gatewayPid']}),flush=True)
summary={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'producerSha256':hashlib.sha256(source.encode()).hexdigest(),'rows':results,'attachments':len(results)}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
