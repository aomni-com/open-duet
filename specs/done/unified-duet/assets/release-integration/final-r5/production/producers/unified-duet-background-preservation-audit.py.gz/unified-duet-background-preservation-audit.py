import concurrent.futures,datetime,hashlib,json,pathlib,re,subprocess,sys
stage=sys.argv[1]
assert stage in ['before','after','after-rg','after-path']
root=pathlib.Path('/tmp/unified-duet-production-background-preservation-261004')
out=root/stage
out.mkdir(parents=True,exist_ok=True)
initial=json.loads(pathlib.Path('/tmp/unified-duet-production-adoption-fixed-fleet-261004.json').read_text())
rows=[row for row in initial['outcomes'] if row['status']=='deferred' and row.get('reason')=='Runner processes are active']
assert len(rows)==5
if len(sys.argv)>2:
 rows=[row for row in rows if row['vmName']==sys.argv[2]]
 assert len(rows)==1
remote='''import datetime,json,pathlib,subprocess
expected=EXPECTED
def proc(pid):
 root=pathlib.Path('/proc')/str(pid)
 fields=(root/'stat').read_text().rpartition(') ')[2].split()
 return {'pid':pid,'parentPid':int(fields[1]),'startedTicks':fields[19],'state':fields[0],'cgroups':(root/'cgroup').read_text().strip().splitlines()}
def unit(name):
 keys=['MainPID','ControlPID','ActiveState','SubState','ControlGroup']
 p=subprocess.run(['systemctl','show',name,'--property='+','.join(keys)],capture_output=True,text=True,timeout=10)
 assert p.returncode==0
 value=dict(line.split('=',1) for line in p.stdout.splitlines() if '=' in line)
 if int(value['MainPID']):value['mainIdentity']=proc(int(value['MainPID']))
 return value
observed=[]
for before in expected['processes']:
 actual=proc(before['pid'])
 assert all(actual[key]==before[key] for key in ['pid','parentPid','startedTicks','cgroups']), 'Background identity changed'
 assert actual['state'] not in ['T','t','Z','X'], 'Background process stopped or exited'
 assert all(proc(before['pid'])[key]==actual[key] for key in ['pid','parentPid','startedTicks','cgroups']), 'Background process changed during read'
 observed.append(actual)
boot=pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip()
assert boot==expected['bootId'], 'OS boot changed'
print(json.dumps({'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'bootId':boot,'processes':observed,'services':{name:unit(name) for name in ['duet-gateway.service','duet-syncthing.service','duet-desktop.service','duet-desktop-browser.service','duet-runtime-adoption.service']}},sort_keys=True))
'''
def audit(row):
 vm=row['vmName'];assert re.fullmatch(r'duet-ws-[a-f0-9]{24}',vm) and row['sshDest']==vm+'.service.example.invalid'
 source=pathlib.Path('/tmp/unified-duet-production-fixed-fleet-audits')/(vm+'-context.json')
 old=json.loads(source.read_text())
 script=remote.replace('EXPECTED',repr({'bootId':old['bootId'],'processes':old['processes']}))
 p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','-o','ServerAliveInterval=15','-o','ServerAliveCountMax=2',row['sshDest'],'sudo -n python3 -'],input=script,capture_output=True,text=True,timeout=60)
 if p.returncode:
  (out/(vm+'-error.txt')).write_text(p.stderr)
  raise RuntimeError(vm+' metadata check failed')
 value=json.loads(p.stdout)
 value.update({'vmName':vm,'workspaceId':row['workspaceId'],'originalContextSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'producerSha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()})
 if stage!='before':
  before=json.loads((root/'before'/(vm+'.json')).read_text())
  assert before['bootId']==value['bootId']
  for name in ['duet-syncthing.service','duet-desktop.service','duet-desktop-browser.service']:
   previous=before['services'][name];actual=value['services'][name]
   assert previous['MainPID']==actual['MainPID'], name+' PID changed'
   if previous.get('mainIdentity'):
    assert all(previous['mainIdentity'][key]==actual['mainIdentity'][key] for key in ['pid','startedTicks','cgroups']), name+' identity changed'
  assert value['services']['duet-runtime-adoption.service']['ActiveState']=='inactive'
  assert value['services']['duet-runtime-adoption.service']['MainPID']=='0'
 (out/(vm+'.json')).write_text(json.dumps(value,indent=2)+'\n')
 return {'vmName':vm,'processCount':len(value['processes']),'status':'pass','stage':stage}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for value in pool.map(audit,rows):print(json.dumps(value),flush=True)
