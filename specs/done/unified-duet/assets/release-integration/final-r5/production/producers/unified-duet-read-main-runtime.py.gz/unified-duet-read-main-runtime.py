import hashlib,json,os,pathlib,shutil,stat,subprocess,urllib.request

root=pathlib.Path('/opt/duet/current')
manifest=json.loads((root/'manifest.json').read_text())
artifacts=[]
for item in manifest['artifacts']:
    path=root/item['name']
    actual={'name':item['name'],'sha256':hashlib.file_digest(path.open('rb'),'sha256').hexdigest(),'byteLength':path.stat().st_size,'mode':stat.S_IMODE(path.stat().st_mode)}
    assert all(actual[key]==item[key] for key in actual)
    artifacts.append(actual)
state=pathlib.Path('/home/synthetic-user/.duet')
request=urllib.request.Request('http://192.0.2.1:3000/health',headers={'Authorization':'Bearer '+(state/'vm-token').read_text().strip()})
with urllib.request.urlopen(request,timeout=3) as response:
    health=json.load(response)
cli=shutil.which('duet')
result={
    'manifest':manifest,'artifactsVerified':artifacts,
    'health':{key:health.get(key) for key in ['runtimeVersion','imageVersion']},
    'bootHealthCertified':health.get('diagnostics',{}).get('bootHealthCertified'),
    'bootId':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
    'current':os.readlink('/opt/duet/current'),
    'cli':cli,'cliPhysicalPath':os.path.realpath(cli),
    'cliVersion':subprocess.check_output([cli,'--version'],text=True,timeout=15).strip(),
    'gatewayBun':subprocess.check_output(['/opt/duet/gateway-runtime/bin/bun','--version'],text=True,timeout=15).strip(),
    'workspaceBun':subprocess.check_output(['/home/synthetic-user/.bun/bin/bun','--version'],text=True,timeout=15).strip(),
    'oldCliRailExists':(state/'cli-rail').exists(),'duetfsOnPath':shutil.which('duetfs'),
    'bootstrapSha256':hashlib.file_digest(pathlib.Path('/opt/duet/bin/runtime-bootstrap.js').open('rb'),'sha256').hexdigest(),
    'gatewayUnitSha256':hashlib.file_digest(pathlib.Path('/etc/systemd/system/duet-gateway.service').open('rb'),'sha256').hexdigest(),
}
boot=json.loads((state/'runtime-boot-state.json').read_text())
result['bootState']={key:boot.get(key) for key in ['attemptedVersion','previousVersion','healthyVersion','healthyAt','consecutiveFailures','quarantinedVersion']}
result['previous']=os.readlink('/opt/duet/previous')
previousRoot=pathlib.Path('/opt/duet/previous')
previousManifest=json.loads((previousRoot/'manifest.json').read_text())
previousArtifacts=[]
for item in previousManifest['artifacts']:
    path=previousRoot/item['name']
    actual={'name':item['name'],'sha256':hashlib.file_digest(path.open('rb'),'sha256').hexdigest(),'byteLength':path.stat().st_size,'mode':stat.S_IMODE(path.stat().st_mode)}
    assert all(actual[key]==item[key] for key in actual)
    previousArtifacts.append(actual)
result['previousManifest']=previousManifest
result['previousArtifactsVerified']=previousArtifacts
retired=['/home/synthetic-user/.duet/runtime-adoption','/run/systemd/system/duet-gateway.service.d/duet-runtime-adoption.conf','/opt/duet/bin/gateway-bootstrap.js']
result['retiredPathsAbsent']={path:subprocess.run(['sudo','-n','test','!','-e',path],timeout=5).returncode==0 for path in retired}
assert all(result['retiredPathsAbsent'].values()), 'Retired private files returned'
result['gatewayPid']=int(subprocess.check_output(['systemctl','show','duet-gateway.service','-p','MainPID','--value'],text=True,timeout=5))
result['heldManagedReleaseExists']=(pathlib.Path('/opt/duet/releases')/'0.0.0+0aac13839e00a21e0972783346f82bb2c4286e5f748089c5aae95f9faab78fb2').exists()
print(json.dumps(result,indent=2))
