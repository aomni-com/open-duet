import assert from 'node:assert/strict'
import { ConvexHttpClient } from '/Users/synthetic-user/.codex/worktrees/232f/duet/node_modules/convex/browser'
import { makeFunctionReference } from '/Users/synthetic-user/.codex/worktrees/232f/duet/node_modules/convex/server'
import { convexUrlsFromDeployment } from '/Users/synthetic-user/.codex/worktrees/232f/duet/packages/contract/src/convex/index.ts'
import { ExeClient } from '/Users/synthetic-user/.codex/worktrees/232f/duet/packages/exe/src/exe.ts'
const [environment, revision, output] = process.argv.slice(2)
const origin = environment === 'production' ? 'https://service.example.invalid' : 'https://service.example.invalid'
assert(environment==='production'||environment==='staging')
assert(process.env.DUET_API_URL===origin)
assert(/^[a-f0-9]{40}$/.test(revision??''))
assert(output?.startsWith('/tmp/')&&output.endsWith('.json'))
assert(!await Bun.file(output).exists())
const client = new ConvexHttpClient(convexUrlsFromDeployment(process.env.CONVEX_DEPLOYMENT!).cloudUrl)
client.setAdminAuth(process.env.CONVEX_DEPLOY_KEY!)
const identity = ()=>client.query(makeFunctionReference('deployment:identity'))
assert.equal((await identity()).revision,revision)
const workspaces:any[]=[];let cursor:string|null=null
for(let pages=0;pages<100;pages++){
 const result:any=await client.query(makeFunctionReference('_system/cli/tableData'),{table:'workspaces',order:'asc',paginationOpts:{numItems:100,cursor}})
 workspaces.push(...result.page)
 if(result.isDone)break
 assert(result.continueCursor && result.continueCursor!==cursor)
 cursor=result.continueCursor
 assert(pages<99)
}
const providers=await new ExeClient({token:process.env.EXE_TOKEN}).list()
const tag=environment==='production'?'duet-production':'duet-staging'
const items=workspaces.filter(w=>w.vmName).map(w=>({workspaceId:w._id,slug:w.slug,vmName:w.vmName,sshDest:w.sshDest,imageRef:w.imageRef,runtimeVersion:w.runtimeVersion,status:w.status,servicingStatus:w.servicingStatus,createdAt:w._creationTime,provider:providers.filter(p=>p.vm_name===w.vmName).map(p=>({vmName:p.vm_name,sshDest:p.ssh_dest,status:p.status,tags:p.tags})),vmAttachRunId:w.vmAttachRunId,vmResizeRunId:w.vmResizeRunId,vmTeardownRunId:w.vmTeardownRunId}))
const unattached=providers.filter(p=>p.tags?.includes(tag)&&!items.some(w=>w.vmName===p.vm_name)).map(p=>({vmName:p.vm_name,sshDest:p.ssh_dest,status:p.status,tags:p.tags}))
assert(items.every(i=>i.provider.length===1&&i.provider[0].sshDest===i.sshDest))
assert.equal(unattached.length,0,'Provider VM lacks backend attachment')
assert.equal((await identity()).revision,revision)
await Bun.write(output,JSON.stringify({environment,revision,observedAt:new Date().toISOString(),items,unattached,vmLessCount:workspaces.filter(w=>!w.vmName).length},null,2)+'\n')
console.log(JSON.stringify({environment,revision,attachments:items.length,unattached:unattached.length,vmLessCount:workspaces.filter(w=>!w.vmName).length}))
