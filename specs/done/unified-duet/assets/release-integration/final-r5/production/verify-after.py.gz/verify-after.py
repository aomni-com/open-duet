import datetime,hashlib,json,pathlib
root=pathlib.Path(__file__).parent
summary=json.loads((root/'verification-readonly.json').read_text())
before=json.loads((root/'apps.json').read_text())
after=json.loads((root/'apps-after.json').read_text())
ready=json.loads((root/'post-reconcile-retry/readiness.json').read_text())
background=json.loads((root/'post-reconcile-retry/background/summary.json').read_text())
byVm={r['vmName']:r for r in before['rows']}
assert len(after['rows'])==len(ready['rows'])==14
for row in after['rows']:
 assert row['readyCheck']['ok']is True and row['readyCheck']['httpStatus']==200
 assert row['configs']==byVm[row['vmName']]['configs']
 assert all(p['tcpAccepting']for p in row['ports']) and len(row['ports'])==len(row['configs'])
assert sum(len(r['configs'])for r in after['rows'])==78
for row in ready['rows']:
 assert row['runtimeVersion']==summary['runtimeVersion']and row['bootHealthCertified']is True and row['runtimeUpdateInFlight']is False
 assert row['bootState']['healthyVersion']==summary['runtimeVersion']and row['bootState']['previousVersion']==summary['previousVersion']
assert background['processesPreserved']==31 and len(background['rows'])==5
summary.update({'status':'production R5 and authorized managed-app readiness verified','observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'freshRequiredReadyReconcileInvoked':True,'managedAppFreshRequiredReadyPassed':78,'freshRequiredReadyHostsPassed':14,'postReconcileManagedAppTCPAccepting':78,'postReconcileIndependentProcessesPreserved':31,'postReconcileHealthCertifiedNoUpdateInFlight':14})
summary['boundaries']=['Production census/backend identity query; read-only SSH physical inventories, boot and process metadata; authorized existing AppSupervisor reconciliation after all R5 boot certifications','All app config hashes unchanged against production R2 and before/after reconciliation; no app config writes or forced gateway/VM restarts','All 31 original independent process identities and service identities observed unchanged after reconciliation; no customer independent service control, signals or provisioning','Required-ready supervisor200 plus TCP78 proves process readiness and socket reachability; no application business-flow assertion','Rollback R4 has actual historical boot certification on the same14 preserved OS boots; R5 only duet artifact changes','Anonymous served-manifest401 was expected; authenticated manifest read only within existing VM process, without credential export','Initial optional post-reconcile concurrent SSH observations hit banner-exchange transport timeouts; preserved failed logs; serial retry passed without another reconciliation or service action']
summary['evidenceSha256']={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted(root.rglob('*'))if p.is_file()and p.name!='verification.json'}
(root/'verification.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items()if k not in ['evidenceSha256','physicalRows','boundaries']}))
