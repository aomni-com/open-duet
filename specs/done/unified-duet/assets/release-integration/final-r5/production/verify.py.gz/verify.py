import datetime,gzip,hashlib,json,pathlib,shutil
root=pathlib.Path(__file__).parent
repo=pathlib.Path('/Users/synthetic-user/.codex/worktrees/232f/duet')
r2=repo/'specs/unified-duet/assets/release-integration/production-r2'
census=json.loads((root/'census.json').read_text())
runtime=json.loads((root/'runtime/summary.json').read_text())
ready=json.loads((root/'readiness.json').read_text())
served=json.loads((root/'served-runtime.json').read_text())
deploy=json.loads((root/'deployment.json').read_text())
apps=json.loads((root/'apps.json').read_text())
oldapps=json.loads(gzip.decompress((r2/'apps-ready.json.gz').read_bytes()))
background=json.loads((root/'background/summary.json').read_text())
assert deploy['revision']==deploy['backend']['revision']==census['revision']=='da3779eb8e153a57c6f7e7f4d28ff7c75afd336a'
assert len(census['items'])==14 and not census['unattached']
assert len(runtime['rows'])==len(ready['rows'])==len(apps['rows'])==14
vms={r['vmName']for r in census['items']}
assert {r['vmName']for r in runtime['rows']}=={r['vmName']for r in ready['rows']}=={r['vmName']for r in apps['rows']}==vms
r5=deploy['runtime']['version'];r4='0.0.0+8d97a2fa2f3bb4ab69a2e8e494cd9d50cdd02002c3667b174c8cb242db4ed7ec'
assert served['version']==r5
servedArtifacts=served['artifacts']
physical=[]
for row in runtime['rows']:
 vm=row['vmName'];o=row['observation']
 old=json.loads(gzip.decompress((r2/vm/'runtime.json.gz').read_bytes()))
 assert o['manifest']['version']==o['health']['runtimeVersion']==o['bootState']['healthyVersion']==o['bootState']['attemptedVersion']==r5
 assert o['bootHealthCertified']is True and o['bootState']['consecutiveFailures']==0 and o['bootState']['quarantinedVersion']is None
 assert o['previousManifest']==old['manifest'] and o['previousManifest']['version']==r4
 assert o['manifest']['artifacts']==servedArtifacts
 assert o['artifactsVerified']==o['manifest']['artifacts'] and len(o['artifactsVerified'])==8
 assert o['previousArtifactsVerified']==o['previousManifest']['artifacts'] and len(o['previousArtifactsVerified'])==8
 assert o['bootId']==old['bootId'] and old['bootHealthCertified']is True
 before={a['name']:a for a in o['previousArtifactsVerified']};now={a['name']:a for a in o['artifactsVerified']}
 changed=sorted(name for name in now if now[name]!=before[name]);assert changed==['duet']
 assert o['cliVersion']=='1.0.0' and o['cliPhysicalPath'].endswith('/'+r5+'/duet')
 assert o['bootstrapSha256']==old['bootstrapSha256'] and o['gatewayUnitSha256']==old['gatewayUnitSha256']
 assert not o['oldCliRailExists']and o['duetfsOnPath']is None and all(o['retiredPathsAbsent'].values())
 physical.append({'vmName':vm,'bootPreserved':True,'currentArtifacts':8,'previousArtifacts':8,'changedArtifacts':changed,'actualR4PreviouslyCertified':True})
for row in ready['rows']:
 assert row['runtimeVersion']==r5 and row['bootHealthCertified']is True and row['runtimeUpdateInFlight']is False
 assert row['bootState']['healthyVersion']==r5 and row['bootState']['previousVersion']==r4
oldrows={r['vmName']:r for r in oldapps['rows']}
for row in apps['rows']:
 assert sorted(row['configs'],key=lambda x:x['appId'])==sorted(oldrows[row['vmName']]['configs'],key=lambda x:x['appId'])
 assert all(p['tcpAccepting']for p in row['ports']) and len(row['ports'])==len(row['configs'])
assert sum(len(r['configs'])for r in apps['rows'])==78
assert background['processesPreserved']==31 and len(background['rows'])==5
(root/'producers').mkdir()
for source in ['/tmp/unified-duet-final-fleet-census.ts','/tmp/unified-duet-observe-main-fleet.py','/tmp/unified-duet-read-main-runtime.py','/tmp/unified-duet-main-managed-app-sanity.ts','/tmp/unified-duet-background-preservation-audit.py']:
 shutil.copyfile(source,root/'producers'/pathlib.Path(source).name)
summary={'status':'read-only production R5 observation verified','observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mainRevision':census['revision'],'runtimeVersion':r5,'previousVersion':r4,'attachments':14,'unattached':0,'backendTotalVmLessRows':census['vmLessCount'],'actualBootCertified':14,'finalHealthCertifiedNoUpdateInFlight':14,'physicalCurrentArtifactsVerified':112,'physicalPreviousArtifactsVerified':112,'changedArtifacts':['duet'],'osBootsPreservedFromR2':14,'independentProcessesPreserved':31,'independentProcessHosts':5,'managedAppConfigsUnchangedFromR2':78,'managedAppTCPAccepting':78,'freshRequiredReadyReconcileInvoked':False,'boundaries':['GET/query/SSH metadata and TCP observations only; no customer service control, signals, provisioning or forced update','Existing managed-app sanity script ran before/read-only phase; its after phase would push reconcile and was intentionally not invoked','No application response or business-flow assertion from TCP acceptance','Original process identity checks pin PID, parent, start ticks and cgroups with non-stopped live state; independent desktop and syncthing service identities also match R2','R5 previous R4 has actual historical boot certification on the same preserved OS boots','Initial anonymous served-manifest request returned expected401; manifest subsequently read on one VM with existing token held only within remote Python process'],'physicalRows':physical}
summary['evidenceSha256']={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted(root.rglob('*'))if p.is_file()and p.name!='verification.json'}
(root/'verification.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items()if k not in ['evidenceSha256','physicalRows','boundaries']}))
