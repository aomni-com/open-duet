import concurrent.futures,datetime,json,pathlib,subprocess
root=pathlib.Path(__file__).parent
rows=json.loads((root/'census.json').read_text())['items']
remote='''import json,pathlib,urllib.request
state=pathlib.Path('/home/synthetic-user/.duet')
headers={'Authorization':'Bearer '+(state/'vm-token').read_text().strip()}
with urllib.request.urlopen(urllib.request.Request('http://192.0.2.1:3000/health',headers=headers),timeout=5)as response:health=json.load(response)
result={'runtimeVersion':health['runtimeVersion'],'bootHealthCertified':health['diagnostics']['bootHealthCertified'],'runtimeUpdateInFlight':health['diagnostics']['runtimeUpdateInFlight'],'bootState':json.loads((state/'runtime-boot-state.json').read_text())}
if SERVED:
 with urllib.request.urlopen(urllib.request.Request('https://service.example.invalid/v1/vm/runtime-release/manifest',headers=headers),timeout=20)as response:result['servedManifest']=json.load(response)
print(json.dumps(result))
'''
def observe(pair):
 index,row=pair
 code=remote.replace('SERVED',repr(index==0))
 child=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15',row['sshDest'],'python3 -'],input=code,capture_output=True,text=True,timeout=45)
 assert child.returncode==0,row['vmName']+' health observation failed'
 x=json.loads(child.stdout);x['vmName']=row['vmName'];x['observedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 return x
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:results=list(pool.map(observe,enumerate(rows)))
(root/'readiness.json').write_text(json.dumps({'rows':results},indent=2)+'\n')
(root/'served-runtime.json').write_text(json.dumps(results[0]['servedManifest'],indent=2)+'\n')
print(json.dumps({'attachments':len(results),'certified':sum(bool(x['bootHealthCertified'])for x in results),'updatesInFlight':sum(bool(x['runtimeUpdateInFlight'])for x in results)}))
