import concurrent.futures,datetime,hashlib,json,pathlib,re,subprocess,time,sys
OUT=pathlib.Path(sys.argv[2]);OUT.mkdir(exist_ok=True)
RECEIPT=pathlib.Path(sys.argv[1])
FROZEN=pathlib.Path('/Users/synthetic-user/.codex/worktrees/232f/duet/artifacts/unified-duet/adoption-held/runtime-release/manifest.json')
held=json.loads(FROZEN.read_text()); served=json.loads(pathlib.Path(sys.argv[3]).read_text()); assert served['environment']=='production'; expected=served['origins'][0]['manifest']; target=expected['version']; assert len(expected['artifacts'])==8 and target!=held['version']
initial=json.loads(RECEIPT.read_text()); assert initial['environment']=='production'; assert len(initial['items'])==14
identities={row['workspaceId']:(row['vmName'],row['sshDest']) for row in initial['items']}; assert len(identities)==14
(OUT/'inventory.json').write_text(json.dumps({'items':initial['items'],'targetVersion':target,'expectedManifest':expected},indent=2)+'\n')
scripts={'runtime':('/tmp/unified-duet-read-r2-final-audit.py','DUET_NO_AUTO_UPGRADE=1 python3 -'),'retirement':('/tmp/unified-duet-read-staging-retirement.py','sudo -n python3 -'),'wiring':('/tmp/unified-duet-production-fixed-fleet-audits/wiring.py','sudo -n python3 -')}
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
provenance={key:{'path':path,'sha256':sha(path),'command':command} for key,(path,command) in scripts.items()}
(OUT/'producer-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
completed={}; notices=set()
def audit(row):
 name=row['vmName']; folder=OUT/name;folder.mkdir(exist_ok=True)
 assert re.fullmatch(r'duet-ws-[a-f0-9]{24}',name) and row['sshDest']==name+'.service.example.invalid'
 observed={}
 for kind,(source,command) in scripts.items():
  p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','-o','ServerAliveInterval=15','-o','ServerAliveCountMax=2',row['sshDest'],command],input=pathlib.Path(source).read_text(),capture_output=True,text=True,timeout=90)
  (folder/(kind+'.json')).write_text(p.stdout)
  if p.returncode:
   (folder/(kind+'-error.txt')).write_text(p.stderr)
   raise RuntimeError(kind+' remote metadata read failed: '+p.stderr[-1200:])
  observed[kind]=json.loads(p.stdout)
 a,r,w=observed['runtime'],observed['retirement'],observed['wiring']
 assert a['manifest']==expected and a['previousManifest']==held, 'Manifest differs from exact held inventory'
 assert a['artifactsVerified']==expected['artifacts'] and a['previousArtifactsVerified']==held['artifacts'], 'Artifact inventory differs'
 assert row['bootIdBefore']==row['bootIdAfter']==a['bootId']==r['bootId'], 'Boot identity mismatch'
 assert a['health']['runtimeVersion']==target and a['bootHealthCertified'] is True
 assert a['bootState']['healthyVersion']==target and a['bootState']['attemptedVersion']==target and a['bootState']['consecutiveFailures']==0 and not a['bootState'].get('quarantinedVersion')
 assert a['gatewayBun']=='1.4.2' and a['workspaceBun']=='1.3.14'
 assert a['cli']=='/usr/local/bin/duet' and a['cliVersion']=='1.0.0' and a['cliPhysicalPath']==a['current']+'/duet'
 assert a['oldCliRailExists'] is False and a['duetfsOnPath'] is None
 assert a['bootstrapSha256']=='b33587a373136cdac66b78cf74f2e05eb2ee7341207d7adafef49045f0b4e1ab' and a['gatewayUnitSha256']=='84677a224fe0385b335a36dc8cb4e9609424a75f49ed138ab671a4f9c8e3b867'
 assert w['gatewayBunSha256']=='a83d263767d839e4d2649ca8e35d07159c7afc99afdc96d731ced29e056dda0c'
 assert w['gateway']['ActiveState']=='active' and w['gateway']['SubState']=='running' and not w['gatewayProcess']['adoptionHeld']
 for prop,path in [('ExecStartPre','bin/runtime-bootstrap.js'),('ExecStart','current/index.js')]:
  assert re.findall(r'argv\[\]=([^;]*);',w['gateway'][prop])==['/opt/duet/gateway-runtime/bin/bun /opt/duet/'+path+' '], 'Effective command differs'
 assert not w['legacy40Exists'] and w['stableCliLink']=='/opt/duet/current/duet' and not r['dropIn']['exists']
 assert r['unitReadExitCode']==0 and r['unit']['ActiveState']=='inactive' and r['unit']['MainPID']=='0' and r['unit']['ControlPID']=='0'
 assert r['jobs'], 'No retained job descriptor'
 for job in r['jobs']:
  assert job['runIdMatchesDirectory'] and job['unitMatchesOwner']
  assert not job['resultFile']['exists'] and not job['settledFile']['exists'] and not job['transferDirectory']['exists'], 'Owned transfer retained'
 for op in r['operations']:
  worker=op.get('recordedWorker')
  assert not(worker and worker.get('exists') and worker.get('sameIdentity') and worker.get('state')!='Z'), 'Owning worker still live'
  assert op['terminal']['phase']=='complete' and op['receipt']['status']=='complete'
 result={'status':'pass','workspaceId':row['workspaceId'],'vmName':name,'slug':row['slug'],'targetVersion':target,'bootId':a['bootId'],'gatewayPid':w['gatewayProcess']['pid'],'gatewayStarted':w['gatewayProcess']['started'],'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ownedRecordedTransfersAbsent':len(r['jobs']),'settlementFilesObserved':False,'settlementProvenance':'Host controller verifies matching settlement before deleting transfers; this audit observes descriptors and absence, not retained settlement records','metadataSha256':{kind:sha(folder/(kind+'.json')) for kind in observed}}
 if row['slug']=='Example User-zhang-s-workspace':
  result['rerunBaseline']={'path':'/tmp/unified-duet-production-fixed-canary-settled-wiring.txt','gatewayPid':137860,'bootId':'7f362cf0-3ec6-46be-a6e5-1e8488688455'}
  assert result['bootId']==result['rerunBaseline']['bootId'], 'Example User OS boot changed'
 if row['slug']=='official-agents-hub': result['rerunBaselineUnavailable']=True
 (folder/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
 return result

rows=[row for row in initial['outcomes'] if row['status']=='complete']
assert len(rows)==14 and initial['joinedEvidence'] is True, 'Joined proof must contain actual14 completed outcomes'
light="""import json,pathlib,urllib.request
s=pathlib.Path('/home/synthetic-user/.duet')
r=urllib.request.Request('http://192.0.2.1:3000/health',headers={'Authorization':'Bearer '+(s/'vm-token').read_text().strip()})
with urllib.request.urlopen(r,timeout=3) as p:h=json.load(p)
print(json.dumps({'runtimeVersion':h.get('runtimeVersion'),'certified':h.get('diagnostics',{}).get('bootHealthCertified')}))
"""
def observe(row):
 p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15',row['sshDest'],'python3 -'],input=light,capture_output=True,text=True,timeout=30)
 if p.returncode:return (row,{'observationFailed':True})
 return (row,json.loads(p.stdout))
end=time.time()+3600
previous=None
while time.time()<end:
 pending=[row for row in rows if row['workspaceId'] not in completed]
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  observations=list(pool.map(observe,pending))
 state={row['vmName']:value for row,value in observations}
 if state!=previous:print(json.dumps({'event':'runtime-progress','target':target,'completed':len(completed),'pending':state}),flush=True);previous=state
 ready=[row for row,value in observations if value.get('runtimeVersion')==target and value.get('certified') is True]
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  futures={pool.submit(audit,row):row for row in ready}
  for future,row in futures.items():
   value=future.result();completed[row['workspaceId']]=value
   print(json.dumps({'event':'runtime-audit-pass','vmName':row['vmName'],'completed':len(completed)}),flush=True)
 summary={'status':'complete' if len(completed)==14 else 'in-progress','targetVersion':target,'sourceRevision':served['sourceRevision'],'previousVersion':held['version'],'rows':list(completed.values()),'inventorySize':14,'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 (OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 if len(completed)==14:break
 time.sleep(30)
else:raise RuntimeError('Read-only observation cap reached; no VM work terminated')
