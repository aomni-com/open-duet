"""Read-only hosted-runtime verification; bearer and optional Vercel bypass stay in memory."""
import datetime
import hashlib
import json
import os
import pathlib
import re
import sys
import time
import urllib.parse
import urllib.request

NAMES = ['duet', 'helper.js', 'index.js', 'initdb.wasm', 'pglite.data', 'pglite.wasm', 'photon_rs_bg.wasm', 'vector.tar.gz']
CANONICAL = {'production': 'https://service.example.invalid', 'staging': 'https://service.example.invalid'}


def parse_inputs(environment, revision, immutable, canonical, output):
    assert environment in CANONICAL, 'Unknown environment'
    assert re.fullmatch('[a-f0-9]{40}', revision), 'Expected a full lowercase source revision'
    assert canonical == CANONICAL[environment], 'Canonical origin does not match environment'
    url = urllib.parse.urlsplit(immutable)
    assert url.scheme == 'https' and url.hostname and url.hostname.endswith('.service.example.invalid'), 'Expected immutable Vercel URL'
    assert url.netloc == url.hostname and url.path in ('', '/') and not url.query and not url.fragment, 'Expected a plain immutable origin'
    immutable = immutable.rstrip('/')
    output = pathlib.Path(output)
    assert str(output).startswith('/tmp/') and output.is_absolute() and str(output) == os.path.normpath(str(output)) and output.suffix == '.json', 'Expected an absolute /tmp JSON receipt'
    assert not output.exists(), 'Receipt already exists'
    return immutable, output


def checked_manifest(manifest):
    assert manifest.get('formatVersion') == 1, 'Unknown runtime manifest format'
    rows = manifest.get('artifacts')
    assert isinstance(rows, list) and [row.get('name') for row in rows] == NAMES, 'Incomplete sorted runtime inventory'
    artifacts = []
    for row in rows:
        assert re.fullmatch('[a-f0-9]{64}', row.get('sha256', '')), 'Invalid artifact digest'
        assert type(row.get('byteLength')) is int and 0 < row['byteLength'] <= 9007199254740991, 'Invalid artifact length'
        assert type(row.get('mode')) is int and row['mode'] == (0o755 if row['name'] == 'duet' else 0o644), 'Artifact installation mode mismatch'
        artifacts.append({key: row[key] for key in ['name', 'sha256', 'byteLength', 'mode']})
    identity = json.dumps({'formatVersion': 1, 'artifacts': artifacts}, separators=(',', ':'))
    assert manifest.get('version') == '0.0.0+' + hashlib.sha256(identity.encode()).hexdigest(), 'Runtime manifest identity mismatch'
    return {'formatVersion': 1, 'version': manifest['version'], 'artifacts': artifacts}


def verify(environment, revision, immutable, canonical, output, token, bypass=None):
    immutable, output = parse_inputs(environment, revision, immutable, canonical, output)
    assert token and '\n' not in token and '\r' not in token, 'VM bearer is absent or malformed'
    headers = {'Authorization': 'Bearer ' + token}
    if bypass:
        headers['x-vercel-protection-bypass'] = bypass

    def get(origin, path):
        response = urllib.request.urlopen(urllib.request.Request(origin + path, headers=headers), timeout=45)
        assert response.status == 200, 'Hosted response was not successful'
        return response

    def deployment(origin):
        with get(origin, '/deployment') as response:
            value = json.load(response)
        assert value.get('revision') == revision and value.get('backend', {}).get('revision') == revision, 'API/backend source revision mismatch'
        assert value['backend'].get('schema') == 1 and value.get('runtime', {}).get('version'), 'Schema or runtime unavailable'
        return value

    origins = []
    for origin in [immutable, canonical]:
        before = deployment(origin)
        with get(origin, '/v1/vm/runtime-release/manifest') as response:
            manifest = checked_manifest(json.load(response))
        assert manifest['version'] == before['runtime']['version'], 'Announcement and served runtime differ'
        observations = []
        for row in manifest['artifacts']:
            started = time.monotonic()
            digest, length = hashlib.sha256(), 0
            with get(origin, '/v1/vm/runtime-release/artifacts/' + row['name']) as response:
                assert int(response.headers['Content-Length']) == row['byteLength'], 'Artifact Content-Length mismatch'
                while chunk := response.read(1024 * 1024):
                    length += len(chunk)
                    assert length <= row['byteLength'], 'Artifact stream exceeded manifest length'
                    digest.update(chunk)
            assert length == row['byteLength'] and digest.hexdigest() == row['sha256'], 'Served artifact bytes do not match manifest'
            observations.append({'name': row['name'], 'sha256': digest.hexdigest(), 'byteLength': length, 'targetMode': row['mode'], 'seconds': round(time.monotonic() - started, 3)})
        after = deployment(origin)
        assert before == after, 'Deployment changed during artifact observation'
        origins.append({'origin': origin, 'deployment': before, 'manifest': manifest, 'verifiedServedArtifacts': observations})
    assert origins[0]['manifest'] == origins[1]['manifest'], 'Immutable and canonical inventories differ'
    result = {'environment': environment, 'sourceRevision': revision, 'observedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'origins': origins, 'runtimeVersion': origins[0]['manifest']['version'], 'runtimeOrWorkspaceWrites': False, 'operatorReceipt': str(output), 'credentialsEmitted': False}
    descriptor = os.open(output, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    with os.fdopen(descriptor, 'w') as handle:
        json.dump(result, handle, indent=2)
        handle.write('\n')
    return result


def main():
    try:
        assert len(sys.argv) == 6, 'Expected environment, source revision, immutable URL, canonical origin, receipt'
        result = verify(*sys.argv[1:], os.environ.get('DUET_RUNTIME_VERIFY_TOKEN', ''), os.environ.get('VERCEL_AUTOMATION_BYPASS_SECRET'))
        print(json.dumps(result, indent=2))
        return 0
    except Exception:
        print('Served runtime verification refused or failed; raw credential-bearing errors are withheld. No receipt certifies this run.', file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
