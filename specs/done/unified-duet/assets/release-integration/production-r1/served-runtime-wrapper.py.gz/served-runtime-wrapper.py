"""Capture an existing VM bearer into a protected child environment; never persist it."""
import hashlib
import importlib.util
import json
import os
import pathlib
import re
import subprocess
import sys

VERIFIER=pathlib.Path('/tmp/unified-duet-production-served-runtime.py')
VERIFIER_SHA='247cd9a0c761493ca8c77edc55a69e2b028576f2c34c4300ff2473b245c80aa2'
BASELINE=pathlib.Path('/tmp/unified-duet-production-pre-fence-plan-261004.json')


def run(arguments):
    assert len(arguments)==6, 'Expected production, verified SSH identity, exact SHA, immutable origin, canonical origin, unique receipt'
    environment,ssh_dest,revision,immutable,canonical,output=arguments
    assert environment=='production', 'Wrapper is production only'
    assert re.fullmatch(r'duet-ws-[a-f0-9]{24}\.exe\.xyz',ssh_dest), 'Expected an exact workspace SSH identity'
    baseline=json.loads(BASELINE.read_text())
    assert baseline['environment']=='production', 'Inventory environment mismatch'
    rows=[row for row in baseline['items'] if row['sshDest']==ssh_dest]
    assert len(rows)==1 and rows[0]['vmName']+'.service.example.invalid'==ssh_dest, 'SSH identity absent or ambiguous in retained verified inventory'
    assert hashlib.sha256(VERIFIER.read_bytes()).hexdigest()==VERIFIER_SHA, 'Verifier producer bytes changed'
    spec=importlib.util.spec_from_file_location('served_verifier',VERIFIER)
    verifier=importlib.util.module_from_spec(spec);spec.loader.exec_module(verifier)
    verifier.parse_inputs(environment,revision,immutable,canonical,output)
    assert os.environ.get('DUET_API_URL')==canonical, 'Inherited production API origin mismatch'
    captured=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15',ssh_dest,'python3 -'],input=b"from pathlib import Path\nimport sys\nsys.stdout.write(Path('/home/synthetic-user/.duet/vm-token').read_text().strip())\n",capture_output=True,timeout=30)
    assert captured.returncode==0, 'VM credential read failed'
    token=captured.stdout.decode().strip()
    assert token and '\n' not in token and '\r' not in token, 'VM credential read was empty or malformed'
    child_env=dict(os.environ);child_env['DUET_RUNTIME_VERIFY_TOKEN']=token
    child=subprocess.run([sys.executable,str(VERIFIER),environment,revision,immutable,canonical,output],env=child_env,capture_output=True,timeout=1200)
    assert child.returncode==0, 'Served verifier failed; inspect outcome before retrying'
    result=json.loads(pathlib.Path(output).read_text())
    assert result['sourceRevision']==revision and result['environment']==environment and result['credentialsEmitted'] is False, 'Receipt identity mismatch'
    summary={'environment':environment,'sourceVm':rows[0]['vmName'],'sshDest':ssh_dest,'sourceRevision':revision,'runtimeVersion':result['runtimeVersion'],'receipt':output,'verifierSha256':VERIFIER_SHA,'credentialsEmitted':False}
    print(json.dumps(summary))
    return 0


def main(arguments):
    try:
        return run(arguments)
    except Exception:
        print('Protected served-runtime observation refused or failed; raw SSH/HTTP output and credentials are withheld. Inspect actual receipt presence before retrying.',file=sys.stderr)
        return 1


if __name__=='__main__':sys.exit(main(sys.argv[1:]))
