import pathlib,os,json,stat
p=pathlib.Path('/proc/1275915');env=dict(x.split(b'=',1) for x in p.joinpath('environ').read_bytes().split(b'\0') if b'=' in x);entries=env[b'PATH'].decode().split(':');d=pathlib.Path(entries[0]);manifest=json.loads((d.parent/'package.json').read_text());name=manifest['name'];later=[]
for entry in entries[1:]:
 candidate=pathlib.Path(entry)/'rg'
 if candidate.exists():later.append({'outsideRetiringInstall':not str(candidate.resolve()).startswith(('/opt/duet/','/home/synthetic-user/.duet/cli-rail/')),'executable':os.access(candidate,os.X_OK),'usrBin':str(candidate)=='/usr/bin/rg'})
print(json.dumps({'pid':1275915,'ownerVscodeRipgrep':name=='@vscode/ripgrep','ownerVscodeRipgrepLinux':name.startswith('@vscode/ripgrep-'),'ownerDuetRg':name.startswith('@duetso/') and 'rg' in name,'ownerPiTools':name.startswith('@mariozechner/'),'ownerRipgrepNamed':'ripgrep' in name,'packageBinDeclaresRg':'rg' in manifest.get('bin',{}),'stableRgFallbacks':later},indent=2))
