import base64,gzip,pathlib,tempfile,shutil,json,subprocess,hashlib
p=pathlib.Path('/proc/1275915');identity=p.joinpath('stat').read_text().rpartition(') ')[2].split()[19];env=dict(x.split(b'=',1) for x in p.joinpath('environ').read_bytes().split(b'\0') if b'=' in x);entries=env[b'PATH'].decode().split(':');directory=pathlib.Path(entries[0]);jobs=pathlib.Path('/home/synthetic-user/.duet/runtime-adoption/jobs');job=next(p for p in jobs.iterdir() if hashlib.sha256((p/'supervisor.js').read_bytes()).hexdigest()=='0e0b880610e5a95f53ea15b10b6eea5ff87f8ccff1a506e5b9dc74966ba48428')
scratch=pathlib.Path(tempfile.mkdtemp(prefix='duet-rg-readonly-'));scratch.chmod(0o700)
try:
 source=gzip.decompress(base64.b64decode(PAYLOAD));path=scratch/'predicate.js';path.write_bytes(source)
 code='const {hasBundledRipgrepFallback}=await import('+json.dumps(str(path))+');console.log(JSON.stringify({fallback:await hasBundledRipgrepFallback('+','.join(map(json.dumps,[str(directory),entries[1:],'/home/synthetic-user/.duet/cli-rail','/usr/bin/rg']))+')}));'
 result=subprocess.run([str(job/'gateway-bun'),'-e',code],capture_output=True,text=True,timeout=15);assert result.returncode==0,'Read-only rg predicate failed; stderr withheld'
 def version(file):
  v=subprocess.run([str(file),'--version'],capture_output=True,text=True,timeout=5);assert v.returncode==0;line=v.stdout.splitlines()[0];assert line.startswith('ripgrep ');return line
 assert identity==p.joinpath('stat').read_text().rpartition(') ')[2].split()[19]
 print(json.dumps({'pid':1275915,'startedTicks':identity,'patchedHelperSha256':hashlib.sha256(source).hexdigest(),'realStateMutated':False,'bundledRgVersion':version(directory/'rg'),'stockRgVersion':version('/usr/bin/rg'),**json.loads(result.stdout)},indent=2))
finally:shutil.rmtree(scratch)
