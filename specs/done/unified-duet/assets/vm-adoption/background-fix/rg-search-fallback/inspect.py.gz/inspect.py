import pathlib,hashlib,json,re,subprocess,tempfile,shutil
EXPECTED='0e0b880610e5a95f53ea15b10b6eea5ff87f8ccff1a506e5b9dc74966ba48428'
base=pathlib.Path('/home/synthetic-user/.duet/runtime-adoption/jobs')
job=next(p for p in base.iterdir() if hashlib.sha256((p/'supervisor.js').read_bytes()).hexdigest()==EXPECTED)
source=(job/'supervisor.js').read_text();start=source.index('async function inspectAdoptionWork(input)');cut=source.index('    const runnerPids',start)
# Exact read-only process predicate; ledger gates already passed in the receipt.
# Skip their copying/folding here, and instrument only boolean denial sites.
for function,end in [('background','    for (const pid of runnerPids)'),('noRuntimeReferences','    async function absentOwner')]:
 begin=source.index('    async function '+function,start);stop=source.index(end,begin);part=source[begin:stop]
 replacements=[]
 for m in re.finditer('return false;',part):
  line=source[:begin+m.start()].count('\n')+1
  replacements.append((m.start(),m.end(),f'return (globalThis.__denials.push({{pid,site:{line}}}), false);'))
 for a,b,value in reversed(replacements):part=part[:a]+value+part[b:]
 source=source[:begin]+part+source[stop:]
source=source.replace('globalThis.__denials.push({pid,site:27257})', 'globalThis.__denials.push({pid,site:27257,variableName:name2,stableFallback:entries.includes("/usr/local/bin"),components:entries.map((path,index)=>({index,reference:references[index],canonicalLegacyBin:path===resolve3(input.stateDir,"cli-rail/bin"),insideLegacyRail:path.startsWith(resolve3(input.stateDir,"cli-rail")+"/"),exists:Bun.file(path).size>0,candidatePath:path.startsWith(resolve3(input.stateDir,"cli-rail/candidates")+"/"),endsBin:path.endsWith("/bin"),endsDotBin:path.endsWith("/.bin"),trailingSlash:path.endsWith("/"),resolvedCanonicalLegacyBin:resolve3(path)===resolve3(input.stateDir,"cli-rail/bin"),hasNodeModules:path.includes("/node_modules/"),hasAgentModule:path.includes("/node_modules/@duetso/agent/"),endsNodeBin:path.endsWith("/node/bin"),endsBunBin:path.endsWith("/bun/bin"),endsAgentBin:path.endsWith("/agent/bin"),endsVendorBin:path.endsWith("/vendor/bin"),lexicalContainsOnly:pinned(path),candidateAgentBin:/^agent-[0-9]+\.[0-9]+\.[0-9]+[^/]*\/bin$/.test(path.slice(resolve3(input.stateDir,"cli-rail/candidates").length+1)),candidateModulesBin:path.includes("/install/global/node_modules/")&&path.endsWith("/.bin"),runtimeRoot:path.startsWith("/opt/duet"),workspaceBunBin:path==="/home/synthetic-user/.bun/bin"}))})')
# Re-find after instrumentation.
start=source.index('async function inspectAdoptionWork(input)');cut=source.index('    const runnerPids',start)
source=source[:start]+source[start:cut].split('  try {')[0]+'  try {\n'+source[cut:]
def show(prop):
 p=subprocess.run(['systemctl','show','duet-gateway.service','-p',prop,'--value'],capture_output=True,text=True,timeout=10);assert p.returncode==0;return p.stdout.strip()
main=int(show('MainPID'));group=show('ControlGroup');boot=pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip()
scratch=pathlib.Path(tempfile.mkdtemp(prefix='duet-denial-readonly-'));scratch.chmod(0o700)
try:
 path=scratch/'predicate.js';path.write_text(source)
 code='globalThis.__denials=[];const {inspectAdoptionWork}=await import('+json.dumps(str(path))+');const result=await inspectAdoptionWork('+json.dumps({'stateDir':'/home/synthetic-user/.duet','procDir':'/proc','runnerCgroupDir':'/sys/fs/cgroup/runners','mainPid':main,'now':0,'gatewayRoot':'/opt/duet','gatewayCgroupDir':'/sys/fs/cgroup'+group,'appAnchorPaths':[]})+');console.log(JSON.stringify({result,denials:globalThis.__denials}));'
 p=subprocess.run([str(job/'gateway-bun'),'-e',code],capture_output=True,text=True,timeout=30)
 assert p.returncode==0,'Read-only predicate failed (stderr withheld)'
 result=json.loads(p.stdout)
 assert show('MainPID')==str(main)
 print(json.dumps({'helperSha256':EXPECTED,'mainPid':main,'bootId':boot,'ledgerSkippedBecauseReceiptPassed':True,'realStateMutated':False,**result},indent=2))
finally:shutil.rmtree(scratch)
