set -eu
mkdir -p /tmp/fixture-background-state /sys/fs/cgroup/runners/session-fixture-background
systemctl stop duet-gateway.service
DUET_GATEWAY_OWNER_PID=999999 /usr/bin/bash -c 'cd /tmp/fixture-background-state; echo $$ > leader; while [ ! -f go ]; do /bin/sleep 0.1; done; unset DUET_GATEWAY_OWNER_PID; /usr/bin/sleep infinity & echo $! > child; wait' </dev/null >/tmp/fixture-background.log 2>&1 &
leader=$!
echo "$leader" > /sys/fs/cgroup/runners/session-fixture-background/cgroup.procs
touch /tmp/fixture-background-state/go
while [ ! -f /tmp/fixture-background-state/child ]; do sleep 0.1; done
mkdir -p /opt/duet/gateway-runtime/bin /etc/systemd/system/duet-gateway.service.d
cp /frozen/gateway-bun /opt/duet/gateway-runtime/bin/bun
chmod 755 /opt/duet/gateway-runtime/bin/bun
systemctl start duet-syncthing.service duet-gateway.service
