set -eu
id exedev >/dev/null 2>&1 || useradd -m exedev
mkdir -p /opt/duet/bin /opt/duet/releases /home/synthetic-user/.bun/bin /home/synthetic-user/.duet/cli-rail/candidates/agent-0.3.36/install/global /home/synthetic-user/.duet/cli-rail/candidates/agent-0.3.36/bin /home/synthetic-user/.duet/cli-rail/candidates/duetfs-0.1.0/install/global/node_modules/duetfs /home/synthetic-user/.duet/cli-rail/candidates/duetfs-0.1.0/bin /home/synthetic-user/.duet/cli-rail/bin /home/synthetic-user/.duet/chrome/Default /home/synthetic-user/.duet/connected-providers/fixture /home/synthetic-user/.local/state/syncthing /home/synthetic-user/drive
cp /tmp/old-source/workspace-bun /home/synthetic-user/.bun/bin/bun
mv /tmp/old-source/node_modules /home/synthetic-user/.duet/cli-rail/candidates/agent-0.3.36/install/global/node_modules
ln -s ../install/global/node_modules/@duetso/agent/dist/src/cli-entry.js /home/synthetic-user/.duet/cli-rail/candidates/agent-0.3.36/bin/duet
ln -s /home/synthetic-user/.duet/cli-rail/candidates/agent-0.3.36/bin/duet /home/synthetic-user/.duet/cli-rail/bin/duet
printf '{"name":"duetfs","version":"0.1.0"}\n' > /home/synthetic-user/.duet/cli-rail/candidates/duetfs-0.1.0/install/global/node_modules/duetfs/package.json
printf '#!/bin/sh\nprintf "0.1.0\\n"\n' > /home/synthetic-user/.duet/cli-rail/candidates/duetfs-0.1.0/bin/duetfs
chmod +x /home/synthetic-user/.duet/cli-rail/candidates/duetfs-0.1.0/bin/duetfs
ln -s /home/synthetic-user/.duet/cli-rail/candidates/duetfs-0.1.0/bin/duetfs /home/synthetic-user/.duet/cli-rail/bin/duetfs
/home/synthetic-user/.bun/bin/bun -e 'import{createHash}from"node:crypto";import{readFileSync,mkdirSync,copyFileSync,writeFileSync,symlinkSync}from"node:fs";const sha=(p)=>createHash("sha256").update(readFileSync(p)).digest("hex");const m={version:"0.0.0+"+sha("/tmp/old-source/index.js").slice(0,12),sha256:sha("/tmp/old-source/index.js"),helperSha256:sha("/tmp/old-source/helper.js")};const d="/opt/duet/releases/"+m.version;mkdirSync(d);for(const n of["index.js","helper.js"])copyFileSync("/tmp/old-source/"+n,d+"/"+n);writeFileSync(d+"/manifest.json",JSON.stringify(m));symlinkSync(d,"/opt/duet/current");writeFileSync("/tmp/fixture-old-manifest.json",JSON.stringify(m))'
cp /tmp/old-source/gateway-bootstrap.js /opt/duet/bin/gateway-bootstrap.js
cp /tmp/old-source/duet-gateway.service /etc/systemd/system/duet-gateway.service
printf 'export BUN_INSTALL=/home/synthetic-user/.bun\nexport DUET_CLI_RAIL=/home/synthetic-user/.duet/cli-rail\nexport PATH="/home/synthetic-user/.duet/cli-rail/bin:/home/synthetic-user/.bun/bin:$PATH"\n' > /etc/profile.d/duet-path.sh
printf fixture-vm-token > /home/synthetic-user/.duet/vm-token
printf fixture-provider-key > /home/synthetic-user/.duet/connected-providers/fixture/credential
printf fixture-chrome-cookies > /home/synthetic-user/.duet/chrome/Default/Cookies
printf fixture-syncthing-identity > /home/synthetic-user/.local/state/syncthing/identity
printf fixture-drive-data > /home/synthetic-user/drive/unchanged.txt
printf 'exedev ALL=(ALL) NOPASSWD: ALL\n' > /etc/sudoers.d/fixture-exedev
chmod 440 /etc/sudoers.d/fixture-exedev
chown -R exedev:exedev /home/synthetic-user /opt/duet
cat > /etc/systemd/system/duet-fixture-api.service <<'UNIT'
[Service]
ExecStart=/tmp/transfer/gateway-bun /tmp/fake-api.js
UNIT
cat > /etc/systemd/system/duet-syncthing.service <<'UNIT'
[Service]
ExecStart=/bin/sleep infinity
UNIT
systemctl set-environment DUET_API_URL=http://192.0.2.1:3100 DUET_IMAGE_VERSION=0.0.0+fixture_old_image DUET_NO_AUTO_UPGRADE=1
systemctl daemon-reload
systemctl start duet-fixture-api.service duet-gateway.service
