import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readFile, stat, writeFile } from 'node:fs/promises'

import { inspectAdoptionWork } from '/tmp/transfer/platform-helper.js'
const mode = process.argv[2]
assert.equal(mode, 'green')
async function command(...args: string[]) {
  const child = Bun.spawn(args, {
    stdout: 'pipe',
    stderr: 'pipe',
    env: {
      ...process.env,
      DUET_NO_AUTO_UPGRADE: '1',
      PATH: '/home/synthetic-user/.duet/cli-rail/bin:/home/synthetic-user/.bun/bin:' + process.env.PATH,
    },
  })
  const timer = setTimeout(() => child.kill('SIGKILL'), 30000)
  const [out, err, code] = await Promise.all([
    new Response(child.stdout).text(),
    new Response(child.stderr).text(),
    child.exited,
  ]).finally(() => clearTimeout(timer))
  assert.equal(code, 0, `${args[0]} failed: ${err}`)
  return out.trim()
}
const dropin = '/etc/systemd/system/duet-gateway.service.d/40-bun-runtime.conf'
const input = await Bun.file('/tmp/transfer/input.json').json()
const journal = `/home/synthetic-user/.duet/runtime-adoption/${input.targetVersion}/journal.json`
async function backgroundSnapshot() {
  const rows=[]
  for (const role of ['leader','child']) {
    const pid=Number((await readFile('/tmp/fixture-background-state/'+role,'utf8')).trim())
    const fields=(await readFile('/proc/'+pid+'/stat','utf8')).replace(/^.*\) /,'').trim().split(/\s+/)
    rows.push({role,pid,started:fields[19],parent:fields[1],group:await readFile('/proc/'+pid+'/cgroup','utf8')})
  }
  return rows
}
async function snapshot() {
  const bytes = await readFile(dropin).catch(() => null),
    metadata = await stat(dropin).catch(() => null)
  return {
    background: await backgroundSnapshot(),
    bootId: (await readFile('/proc/sys/kernel/random/boot_id', 'utf8')).trim(),
    current: await command('readlink', '/opt/duet/current'),
    main: await command('systemctl', 'show', 'duet-gateway.service', '-p', 'MainPID', '--value'),
    syncthingMain: await command(
      'systemctl',
      'show',
      'duet-syncthing.service',
      '-p',
      'MainPID',
      '--value',
    ),
    dropin:
      bytes && metadata
        ? {
            sha256: createHash('sha256').update(bytes).digest('hex'),
            mode: metadata.mode & 0o7777,
            uid: metadata.uid,
            gid: metadata.gid,
          }
        : null,
    workspaceBun: await command('/home/synthetic-user/.bun/bin/bun', '--version'),
    gatewayBunSha256: createHash('sha256')
      .update(await readFile('/opt/duet/gateway-runtime/bin/bun'))
      .digest('hex'),
    driveSha256: createHash('sha256')
      .update(await readFile('/home/synthetic-user/drive/unchanged.txt'))
      .digest('hex'),
    providerSha256: createHash('sha256')
      .update(await readFile('/home/synthetic-user/.duet/connected-providers/fixture/credential'))
      .digest('hex'),
  }
}
const unexpectedPath = '/etc/systemd/system/duet-gateway.service.d/50-fixture-unexpected.conf'
const unexpectedBytes = '[Service]\nExecStartPre=\nExecStartPre=/usr/bin/true\n'
if (mode === 'unexpected') {
  await writeFile(unexpectedPath, unexpectedBytes)
  await command('systemctl', 'daemon-reload')
}
const before = await snapshot()
if (mode !== 'noop') {
  assert.equal(
    await command(
      '/home/synthetic-user/.bun/bin/bun',
      '--no-install',
      '/home/synthetic-user/.duet/cli-rail/bin/duet',
      '--version',
    ),
    '0.3.36',
  )
  const oldMemory = JSON.parse(
    await command(
      '/home/synthetic-user/.bun/bin/bun',
      '--no-install',
      '/home/synthetic-user/.duet/cli-rail/bin/duet',
      'memory',
      '--db',
      '/home/synthetic-user/.duet/memory.db',
      '--json',
    ),
  ) as { content: string }[]
  assert(oldMemory.some(row => row.content === 'fixture memory must survive runtime adoption'))
}
const initial = Date.now()
let census
while (Date.now() - initial < 30000) {
  const main = Number(
    await command('systemctl', 'show', 'duet-gateway.service', '-p', 'MainPID', '--value'),
  )
  const group = await command(
    'systemctl',
    'show',
    'duet-gateway.service',
    '-p',
    'ControlGroup',
    '--value',
  )
  census = await inspectAdoptionWork({
    stateDir: '/home/synthetic-user/.duet',
    procDir: '/proc',
    runnerCgroupDir: '/sys/fs/cgroup/runners',
    mainPid: main,
    now: Date.now(),
    gatewayRoot: '/opt/duet',
    appAnchorPaths: [],
    gatewayCgroupDir: '/sys/fs/cgroup' + group,
  })
  if (census.idle) break
  await Bun.sleep(500)
}
assert.equal(census?.idle, true, JSON.stringify(census))
const syncsBefore = await Bun.file('/tmp/fixture-api-syncs')
  .text()
  .catch(() => '')
const result = '/tmp/transfer/dropin-' + mode + '-' + Date.now() + '.json'
const launch = JSON.parse(
  await command(
    '/tmp/transfer/gateway-bun',
    '/tmp/transfer/platform-helper.js',
    '__launch',
    '/tmp/transfer/input.json',
    result,
  ),
)
let settled, interrupted
const deadline = Date.now() + 240000
while (Date.now() < deadline) {
  try {
    settled = await Bun.file(launch.settledFile).json()
    break
  } catch {}
  if (mode === 'rollback' && !interrupted) {
    const current = await Bun.file(journal)
      .json()
      .catch(() => null)
    const syncs = (
      await Bun.file('/tmp/fixture-api-syncs')
        .text()
        .catch(() => '')
    )
      .trim()
      .split('\n')
      .filter(Boolean)
      .map(JSON.parse)
    if (
      current?.phase === 'started' &&
      syncs.filter(x => x.version === input.targetVersion).length >= 2
    ) {
      const parent = Number(
        await command('systemctl', 'show', launch.unit, '-p', 'MainPID', '--value'),
      )
      assert(parent > 0)
      interrupted = { phase: current.phase, parent }
      process.kill(parent, 'SIGKILL')
    }
  }
  await Bun.sleep(100)
}
assert(settled, 'Platform did not settle')
assert.equal(settled.runId, launch.runId)
assert.equal(settled.settled, true)
const settlementDeadline = Date.now() + 10000
let job
while (Date.now() < settlementDeadline) {
  job = await command(
    'systemctl',
    'show',
    launch.unit,
    '-p',
    'ActiveState',
    '-p',
    'MainPID',
    '-p',
    'ControlPID',
  )
  if (
    job.includes('ActiveState=inactive') &&
    job.includes('MainPID=0') &&
    job.includes('ControlPID=0')
  )
    break
  await Bun.sleep(100)
}
assert(
  job?.includes('ActiveState=inactive') &&
    job.includes('MainPID=0') &&
    job.includes('ControlPID=0'),
  job,
)
const receipt = await Bun.file(result).json(),
  after = await snapshot()
const observation = {
  mode,
  launch,
  receipt,
  settled,
  interrupted,
  job,
  before,
  after,
  effectiveExecStart: await command(
    'systemctl',
    'show',
    'duet-gateway.service',
    '-p',
    'ExecStart',
    '--value',
  ),
  effectiveExecStartPre: await command(
    'systemctl',
    'show',
    'duet-gateway.service',
    '-p',
    'ExecStartPre',
    '--value',
  ),
}
await Bun.write(
  `/tmp/transfer/${mode}-observation.json`,
  JSON.stringify(observation, null, 2) + '\n',
)
console.log(JSON.stringify(observation, null, 2))
assert.deepEqual(before.background, after.background)
assert.equal(before.bootId, after.bootId)
assert.equal(before.syncthingMain, after.syncthingMain)
assert.equal(before.workspaceBun, after.workspaceBun)
assert.equal(before.gatewayBunSha256, after.gatewayBunSha256)
assert.equal(before.driveSha256, after.driveSha256)
assert.equal(before.providerSha256, after.providerSha256)
if (mode === 'green' || mode === 'red' || mode === 'noop') {
  if (mode === 'noop') assert.equal(before.main, after.main)
  assert.equal(receipt.status, 'complete')
  assert.equal(after.dropin, null)
  const health = await (
    await fetch('http://192.0.2.1:3000/health', {
      headers: { authorization: 'Bearer [REDACTED]' },
    })
  ).json()
  assert.equal(health.runtimeVersion, input.targetVersion)
  assert.equal(health.diagnostics.bootHealthCertified, true)
  const memory = JSON.parse(
    await command(
      '/usr/local/bin/duet',
      'memory',
      '--db',
      '/home/synthetic-user/.duet/memory.db',
      '--json',
    ),
  )
  assert(
    (memory as { content: string }[]).some(
      row => row.content === 'fixture memory must survive runtime adoption',
    ),
  )
} else {
  assert.equal(receipt.status, mode === 'unexpected' ? 'deferred' : 'failed')
  assert.equal(receipt.restored, true)
  assert.deepEqual(after.dropin, before.dropin)
  assert.equal(after.current, before.current)
  if (mode === 'rollback') assert(interrupted)
  if (mode === 'unexpected') {
    const newSyncs = (await Bun.file('/tmp/fixture-api-syncs').text()).slice(syncsBefore.length)
    assert(
      !newSyncs.includes(input.targetVersion),
      'An unexpected command override must not start the target',
    )
    assert.equal(await readFile(unexpectedPath, 'utf8'), unexpectedBytes)
  }
}
