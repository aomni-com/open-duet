import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { inspectAdoptionWork } from '/tmp/transfer/platform-helper.js'
async function show(key:string) { return (await new Response(Bun.spawn(['systemctl','show','duet-gateway.service','-p',key,'--value'],{stdout:'pipe'}).stdout).text()).trim() }
const main=Number(await show('MainPID')), group=await show('ControlGroup')
const work=await inspectAdoptionWork({stateDir:'/home/synthetic-user/.duet',procDir:'/proc',runnerCgroupDir:'/sys/fs/cgroup/runners',mainPid:main,now:Date.now(),gatewayRoot:'/opt/duet',gatewayCgroupDir:'/sys/fs/cgroup'+group,appAnchorPaths:[]})
assert.equal(work.idle,true,JSON.stringify(work))
const prior=await Bun.file('/tmp/transfer/green-observation.json').json()
for(const row of prior.after.background) {
const stat=(await readFile('/proc/'+row.pid+'/stat','utf8')).replace(/^.*\) /,'').trim().split(/\s+/)
assert.equal(stat[19],row.started);assert.equal(stat[1],row.parent);assert.equal(await readFile('/proc/'+row.pid+'/cgroup','utf8'),row.group)
}
console.log(JSON.stringify({work,main,background:prior.after.background,bootId:(await readFile('/proc/sys/kernel/random/boot_id','utf8')).trim(),helperSha256:new Bun.CryptoHasher('sha256').update(await Bun.file('/tmp/transfer/platform-helper.js').arrayBuffer()).digest('hex')}))
