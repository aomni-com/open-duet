import assert from 'node:assert/strict'
import { readFile,writeFile,mkdir } from 'node:fs/promises'
import { inspectAdoptionWork } from '/tmp/transfer/platform-helper.js'
async function show(key:string) { return (await new Response(Bun.spawn(['systemctl','show','duet-gateway.service','-p',key,'--value'],{stdout:'pipe'}).stdout).text()).trim() }
const main=Number(await show('MainPID')),group=await show('ControlGroup'),leaf='/sys/fs/cgroup/runners/session-fixture-negative'
await mkdir(leaf,{recursive:true});const rows=[]
for(const kind of ['current-owner','unknown-owner','rpc']) {
 const env={PATH:'/usr/local/bin:/usr/bin:/bin',...(kind==='current-owner'?{DUET_GATEWAY_OWNER_PID:String(main)}:kind==='rpc'?{DUET_GATEWAY_OWNER_PID:'999999'}:{})}
 const child=Bun.spawn(['/usr/bin/bash','-c','read -t 3600 unused',...(kind==='rpc'?['--rpc']:[])],{env,stdin:'pipe',stdout:'ignore',stderr:'ignore'})
 await writeFile(leaf+'/cgroup.procs',String(child.pid));const before=await readFile('/proc/'+child.pid+'/stat','utf8')
 const result=await inspectAdoptionWork({stateDir:'/home/synthetic-user/.duet',procDir:'/proc',runnerCgroupDir:'/sys/fs/cgroup/runners',mainPid:main,now:Date.now(),gatewayRoot:'/opt/duet',gatewayCgroupDir:'/sys/fs/cgroup'+group,appAnchorPaths:[]})
 assert.equal(result.idle,false);assert.equal(Number(await show('MainPID')),main)
 const after=await readFile('/proc/'+child.pid+'/stat','utf8');const identity=(s:string)=>s.replace(/^.*\) /,'').trim().split(/\s+/)[19]
 assert.equal(identity(before),identity(after));rows.push({kind,pid:child.pid,start:identity(after),result,gatewayMainUnchanged:true,processUninterrupted:true})
 child.kill('SIGTERM');await child.exited
}
console.log(JSON.stringify(rows,null,2))
