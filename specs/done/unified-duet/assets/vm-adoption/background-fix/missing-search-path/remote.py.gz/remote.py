import pathlib,json,hashlib,base64,gzip,tempfile,subprocess,shutil,re
source=gzip.decompress(base64.b64decode(PAYLOAD)).decode();original=source;EXPECTED='f15806e27bc53a0242f02500ea1c5235536e6bc9b288f2462783acbd1b6c714a';assert hashlib.sha256(source.encode()).hexdigest()==EXPECTED
jobs=pathlib.Path('/home/synthetic-user/.duet/runtime-adoption/jobs');job=next(p for p in jobs.iterdir() if (p/'gateway-bun').exists());run=json.loads((job/'run.json').read_text())
# Instrument the exact process predicate only. No ledger folding/copying or cuts.
start=source.index('async function inspectAdoptionWork(input)')
for function,end in [('background','    for (const pid of runnerPids)'),('noRuntimeReferences','    async function absentOwner')]:
 begin=source.index('    async function '+function,start);stop=source.index(end,begin);part=source[begin:stop];replacements=[]
 for m in re.finditer('return false;',part):
  line=original[:original.index('    async function '+function,start)+m.start()].count('\n')+1
  replacements.append((m.start(),m.end(),f'return (globalThis.__denials.push({{pid,site:{line}}}), false);'))
 for a,b,value in reversed(replacements):part=part[:a]+value+part[b:]
 if function=='background':part=part.replace('      } finally {','      } catch(error) { globalThis.__denials.push({pid,readErrorCode:error.code??"unknown"}); return false; } finally {')
 source=source[:begin]+part+source[stop:]
# Enrich only the identified environment-denial site with variable names/flags.
source=source.replace('globalThis.__denials.push({pid,site:27295})', 'globalThis.__denials.push({pid,site:27295,variableName:name2,stableFallback:entries.includes("/usr/local/bin"),components:await Promise.all(entries.map(async(path,index)=>({index,reference:references[index],canonicalRailBin:path===resolve3(input.stateDir,"cli-rail/bin"),insideRail:path.startsWith(resolve3(input.stateDir,"cli-rail")+"/"),vscodeRgPackageBin:/\\/node_modules\\/@vscode\\/ripgrep-[^/]+\\/bin$/.test(path),knownRgFallback:references[index]?await hasBundledRipgrepFallback(path,entries.slice(index+1),resolve3(input.stateDir,"cli-rail"),"/usr/bin/rg"):null})))})')
start=source.index('async function inspectAdoptionWork(input)');cut=source.index('    const runnerPids',start);source=source[:start]+source[start:cut].split('  try {')[0]+'  try {\n'+source[cut:]
source=source.replace('''    for (const pid of runnerPids) {
      if (!await background(pid))
        return { idle: false, reason: "Runner processes are active" };
    }''','''    for (const pid of runnerPids) {
      const allowed = await background(pid);const p=processes.get(pid);
      globalThis.__classification.push({pid,allowed,parent:p?.parent,started:p?.started,rpc:p?.args.includes(RUNNER_RPC_FLAG),ownerMarkerPresent:p?.env?.some(value=>value.startsWith(`${RUNNER_OWNER_ENV}=`)),outsideGatewayTree:!belongsToGateway(pid)});
    }''')
source=source.replace('''          if (!await background(pid))
            return { idle: false, reason: "Runner processes are active" };''','''          const allowed=await background(pid);if(!runnerPids.has(pid)){const p=processes.get(pid);globalThis.__classification.push({pid,allowed,parent:p?.parent,started:p?.started,knownDescendant:true});}''')
# RPC remains denied; record it without stopping classification of the rest.
source=source.replace('return { idle: false, reason: "Runner processes are active" };','globalThis.__denials.push({pid:typeof pid!=="undefined"?pid:Number(name),ownedRpc:true});')
def show(prop):
 p=subprocess.run(['systemctl','show','duet-gateway.service','-p',prop,'--value'],capture_output=True,text=True,timeout=10);assert p.returncode==0;return p.stdout.strip()
main=int(show('MainPID'));group=show('ControlGroup');boot=pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip();scratch=pathlib.Path(tempfile.mkdtemp(prefix='duet-cohort-readonly-'));scratch.chmod(0o700)
try:
 path=scratch/'predicate.js';path.write_text(source)
 inputs={'stateDir':'/home/synthetic-user/.duet','procDir':'/proc','runnerCgroupDir':'/sys/fs/cgroup/runners','mainPid':main,'now':0,'gatewayRoot':'/opt/duet','gatewayCgroupDir':'/sys/fs/cgroup'+group,'appAnchorPaths':ANCHORS}
 code='globalThis.__denials=[];globalThis.__classification=[];const {inspectAdoptionWork}=await import('+json.dumps(str(path))+');const finalObservation=await inspectAdoptionWork('+json.dumps(inputs)+');console.log(JSON.stringify({finalObservation,classification:globalThis.__classification,denials:globalThis.__denials}));'
 p=subprocess.run([str(job/'gateway-bun'),'-e',code],capture_output=True,text=True,timeout=45);assert p.returncode==0,'Read-only process classification failed; stderr withheld'
 result=json.loads(p.stdout);assert show('MainPID')==str(main)
 print(json.dumps({'helperSha256':EXPECTED,'gatewayMain':main,'bootId':boot,'processClassificationOnly':True,'ledgerSkipped':True,'actualAdoptionPermissionClaimed':False,'realStateMutated':False,**result},indent=2))
finally:shutil.rmtree(scratch)
