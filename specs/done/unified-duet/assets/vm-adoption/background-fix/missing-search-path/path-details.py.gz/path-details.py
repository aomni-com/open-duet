import pathlib,os,json,re
root=pathlib.Path('/sys/fs/cgroup/runners');pids=set();rail='/home/synthetic-user/.duet/cli-rail/';rows=[]
for path in [root/'cgroup.procs',*root.glob('**/cgroup.procs')]:
 try:pids.update(map(int,path.read_text().split()))
 except FileNotFoundError:pass
for pid in sorted(pids):
 try:
  proc=pathlib.Path('/proc')/str(pid);fields=proc.joinpath('stat').read_text().rpartition(') ')[2].split();env=dict(x.split(b'=',1) for x in proc.joinpath('environ').read_bytes().split(b'\0') if b'=' in x);entries=env.get(b'PATH',b'').decode().split(':');details=[]
  for i,entry in enumerate(entries):
   if not entry.startswith(rail):continue
   p=pathlib.Path(entry);isrg=bool(re.search(r'/node_modules/@vscode/ripgrep-[^/]+/bin$',entry));names=set(os.listdir(p)) if p.is_dir() else set();owner=None
   if isrg and (p.parent/'package.json').exists():owner=json.loads((p.parent/'package.json').read_text()).get('name')
   fallback=None
   for later in entries[i+1:]:
    candidate=pathlib.Path(later)/'rg'
    if str(candidate).startswith(rail):continue
    if candidate.is_file() and os.access(candidate,os.X_OK):fallback={'isStock':str(candidate.resolve())==str(pathlib.Path('/usr/bin/rg').resolve()),'executable':True};break
   details.append({'index':i,'canonicalRailBin':entry==rail+'bin','rgPackageSearchBin':isrg,'pathExists':p.exists(),'directoryExists':p.is_dir(),'directoryEntryCount':len(names),'rgOnly':names=={'rg'},'platformPackageOwner':isinstance(owner,str) and owner.startswith('@vscode/ripgrep-'),'ownerMatchesDirectory':isinstance(owner,str) and p.parent.name==owner.removeprefix('@vscode/'),'resolvedInsideRail':str(p.resolve()).startswith(str(pathlib.Path(rail).resolve())+'/'),'firstSurvivingRgFallback':fallback})
  rows.append({'pid':pid,'started':fields[19],'parent':int(fields[1]),'PATHhasStableDuetFallback':'/usr/local/bin' in entries,'components':details})
 except FileNotFoundError:rows.append({'pid':pid,'exitedDuringRead':True})
print(json.dumps({'processes':rows,'processClassificationOnly':True,'ledgerSkipped':True,'realStateMutated':False},indent=2))
