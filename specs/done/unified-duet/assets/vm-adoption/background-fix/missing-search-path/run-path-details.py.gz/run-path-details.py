import pathlib,gzip,base64,json,subprocess,concurrent.futures
root=pathlib.Path('/tmp/unified-duet-background-cohort-classification');source=root/'path-details.py';payload=base64.b64encode(gzip.compress(pathlib.Path('/tmp/unified-duet-Example User-background-denial/vm-runtime-adoption-rg-fixed.js').read_bytes())).decode();plan=json.load(open('/tmp/unified-duet-production-adoption-background-rg-Example User-261004.json'));names={'Example User-a-s-workspace','consigliere','phydra','total-talent-mindset','newera'};rows=[r for r in plan['items'] if r['slug'] in names];assert len(rows)==5

def run(row):
 script='PAYLOAD='+repr(payload)+'\nANCHORS='+repr(row['appAnchorPaths'])+'\n'+source.read_text();p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15',row['sshDest'],'sudo -n python3 -'],input=script,text=True,capture_output=True,timeout=70);(root/(row['vmName']+'-path-details.json')).write_text(p.stdout);(root/(row['vmName']+'-path-details-error.txt')).write_text(p.stderr);print(json.dumps({'vmName':row['vmName'],'exitCode':p.returncode}),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,rows))
