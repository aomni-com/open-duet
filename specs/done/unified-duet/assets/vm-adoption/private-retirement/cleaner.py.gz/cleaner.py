"""Single-use private transition cleanup. Default inspection; never restart anything."""
import argparse,contextlib,hashlib,io,json,os,pathlib,re,runpy,shutil,stat,subprocess,time,urllib.request

ROOT=pathlib.Path('/home/synthetic-user/.duet/runtime-adoption')
HELD='0.0.0+0aac13839e00a21e0972783346f82bb2c4286e5f748089c5aae95f9faab78fb2'
NAMES=['duet','helper.js','index.js','initdb.wasm','pglite.data','pglite.wasm','photon_rs_bg.wasm','vector.tar.gz']
OLD_BOOTSTRAP=pathlib.Path('/opt/duet/bin/gateway-bootstrap.js')
mutation_started=False
class Blocked(Exception): pass
def need(value,reason):
    if not value: raise Blocked(reason)
def read(path):
    with pathlib.Path(path).open() as source: return json.load(source)
def global_gate(acceptance):
    gate=acceptance.get('globalGate',{})
    need(gate.get('bothFleetsStrictCertified') is True,'both_fleets_gate_unmet')
    need(gate.get('fiveDrillsPassedAndCleaned') is True,'five_drills_gate_unmet')
    need(gate.get('evidencePaths'),'global_evidence_references_missing')
def cohort(link):
    path=pathlib.Path(link).resolve(strict=True)
    need(path.parent==pathlib.Path('/opt/duet/releases') and path.name!=HELD,'nonordinary_release_link')
    manifest=read(path/'manifest.json')
    need(manifest.get('formatVersion')==1 and [row.get('name') for row in manifest.get('artifacts',[])]==NAMES,'incomplete_runtime_inventory')
    for item in manifest['artifacts']:
        asset=path/item['name']; info=asset.lstat()
        need(stat.S_ISREG(info.st_mode) and info.st_size==item['byteLength'] and stat.S_IMODE(info.st_mode)==item['mode'] and item['mode']==(0o755 if item['name']=='duet' else 0o644),'artifact_metadata_mismatch')
        with asset.open('rb') as source: need(hashlib.file_digest(source,'sha256').hexdigest()==item['sha256'],'artifact_hash_mismatch')
    canonical=json.dumps({'formatVersion':1,'artifacts':[{key:item[key] for key in ['name','sha256','byteLength','mode']} for item in manifest['artifacts']]},separators=(',',':'))
    need(manifest['version']=='0.0.0+'+hashlib.sha256(canonical.encode()).hexdigest() and path.name==manifest['version'],'runtime_identity_mismatch')
    return {'path':str(path),'version':manifest['version'],'artifacts':manifest['artifacts']}
def retiring_processes(path=ROOT,exact=False):
    matches=[]; deadline=time.monotonic()+15
    prefix=str(path).encode()
    def uses(value): return value in [str(path),str(path)+' (deleted)'] if exact else value.startswith(str(path)+'/')
    for entry in pathlib.Path('/proc').iterdir():
        if not entry.name.isdigit(): continue
        need(time.monotonic()<deadline,'process_census_timed_out')
        try:
            command=(entry/'cmdline').read_bytes()
            if not command and not exact: continue
            used=prefix in command.split(b'\0') if exact else prefix in command
            for name in ['exe','cwd']:
                try: used=used or uses(os.readlink(entry/name))
                except FileNotFoundError: pass
            if not used:
                for descriptor in (entry/'fd').iterdir():
                    try:
                        if uses(os.readlink(descriptor)): used=True;break
                    except FileNotFoundError: pass
            if used: matches.append({'pid':int(entry.name),('usesRetiringPath' if exact else 'usesRetiringTree'):True})
        except (FileNotFoundError,ProcessLookupError): continue
    return matches
def old_bootstrap():
    try: info=OLD_BOOTSTRAP.lstat()
    except FileNotFoundError: return {'path':str(OLD_BOOTSTRAP),'exists':False}
    result={'path':str(OLD_BOOTSTRAP),'exists':True,'type':'file' if stat.S_ISREG(info.st_mode) else 'symlink' if stat.S_ISLNK(info.st_mode) else 'other','mode':stat.S_IMODE(info.st_mode),'uid':info.st_uid,'gid':info.st_gid,'byteLength':info.st_size}
    if stat.S_ISREG(info.st_mode):
        with os.fdopen(os.open(OLD_BOOTSTRAP,os.O_RDONLY|os.O_NOFOLLOW),'rb') as source: result['sha256']=hashlib.file_digest(source,'sha256').hexdigest()
    return result
def effective_wiring():
    result={}
    for directive,entry in [('ExecStartPre','bin/runtime-bootstrap.js'),('ExecStart','current/index.js')]:
        value=subprocess.check_output(['systemctl','show','duet-gateway.service','-p',directive,'--value'],text=True,timeout=10)
        commands=[match.strip() for match in re.findall(r'argv\[\]=([^;]*);',value)]
        executables=[match.strip() for match in re.findall(r'\{\s*path=([^;]*);',value)]
        result[directive]=executables==['/opt/duet/gateway-runtime/bin/bun'] and commands==['/opt/duet/gateway-runtime/bin/bun /opt/duet/'+entry]
    return result
def bootstrap_gate(observed,acceptance):
    need(all(observed['effectiveWiring'].get(key) is True for key in ['ExecStartPre','ExecStart']),'effective_runtime_wiring_changed')
    need(not observed['processesUsingOldBootstrap'],'old_bootstrap_still_used')
    old=observed['oldBootstrap']
    if not old['exists']: return None
    need(old.get('type')=='file' and old.get('sha256')==acceptance['vm'].get('oldBootstrapSha256'),'old_bootstrap_identity_mismatch')
    return str(OLD_BOOTSTRAP)
def inspect():
    # Reuse the already reviewed metadata reader; its printed result stays in memory.
    with contextlib.redirect_stdout(io.StringIO()):
        metadata=runpy.run_path(str(pathlib.Path(__file__).with_name('unified-duet-read-staging-retirement.py')))['output']
    current=cohort('/opt/duet/current');previous=cohort('/opt/duet/previous')
    state=pathlib.Path('/home/synthetic-user/.duet')
    request=urllib.request.Request('http://192.0.2.1:3000/health',headers={'Authorization':'Bearer '+(state/'vm-token').read_text().strip()})
    with urllib.request.urlopen(request,timeout=5) as response: health=json.load(response)
    gateway_pid=int(subprocess.check_output(['systemctl','show','duet-gateway.service','-p','MainPID','--value'],text=True,timeout=10).strip())
    boot=read(state/'runtime-boot-state.json')
    return {'metadata':metadata,'current':current,'previous':previous,'gatewayPid':gateway_pid,'healthyRuntime':health.get('runtimeVersion'),'bootHealthCertified':health.get('diagnostics',{}).get('bootHealthCertified'),'healthyBootStateVersion':boot.get('healthyVersion'),'processesUsingRetiringTree':retiring_processes(),'oldBootstrap':old_bootstrap(),'effectiveWiring':effective_wiring(),'processesUsingOldBootstrap':retiring_processes(OLD_BOOTSTRAP,exact=True)}
def local_gate(observed,acceptance):
    expected=acceptance['vm'];meta=observed['metadata']
    need(meta['bootId']==expected['bootId'] and observed['gatewayPid']==expected['gatewayPid'] and observed['gatewayPid']>0,'vm_or_gateway_identity_changed')
    need(observed['current']['version']==expected['currentVersion'] and observed['previous']['version']==expected['previousVersion'] and expected['previousCertifiedVersion']==expected['previousVersion'] and expected['currentVersion']!=expected['previousVersion'],'certified_pair_changed')
    need(observed['bootHealthCertified'] is True and observed['healthyRuntime']==expected['currentVersion'] and observed['healthyBootStateVersion']==expected['currentVersion'],'current_not_certified')
    unit=meta['unit']
    need(unit.get('LoadState')=='not-found' and unit.get('ActiveState')=='inactive' and unit.get('MainPID')=='0' and unit.get('ControlPID')=='0' and unit.get('ControlGroup')=='','adoption_job_not_collected')
    need(not meta['dropIn']['exists'] and not observed['processesUsingRetiringTree'],'retiring_tree_still_used')
    need([pathlib.Path(row['root']['path']).name for row in meta['operations']]==[HELD],'unknown_operation_roots')
    operation=meta['operations'][0]
    need(operation['terminal'].get('targetVersion')==HELD and operation['terminal'].get('phase')=='complete' and operation['receipt'].get('status')=='complete' and operation['receipt'].get('phase')=='complete','operation_not_complete')
    need(not operation.get('recordedWorker',{}).get('sameIdentity',False) and not operation.get('recordedMain',{}).get('sameIdentity',False),'pinned_process_remains')
    jobs=meta['jobs'];need(sorted(row['run']['runId'] for row in jobs)==sorted(expected['jobRunIds']),'unknown_job_inventory')
    history=acceptance['hostAdoptionOutcome']
    need(history.get('status')=='complete' and history.get('phase')=='complete' and history.get('targetVersion')==HELD and history.get('transferCleanupPending') is None and history.get('sourceReceipt'),'host_settlement_evidence_missing')
    transfers=[]
    for job in jobs:
        need(job['runIdMatchesDirectory'] and job['unitMatchesOwner'] and job['targetVersion']==HELD,'job_identity_mismatch')
        directory=job['transferDirectory']['path']
        need(re.fullmatch(r'/tmp/duet-runtime-adoption-[0-9a-f-]{36}',directory) and job['run']['resultFile']==directory+'/result.json' and job['run']['settledFile']==directory+'/result.json.settled.json','unknown_transfer_path')
        if job['transferDirectory']['exists']:
            settled=job['settledFile'].get('observation',{});result=job['resultFile'].get('observation',{})
            need(settled.get('settled') is True and all(settled.get(key)==job['run'][key] for key in ['unit','runId']) and settled.get('targetVersion')==HELD and result.get('targetVersion')==HELD and result.get('status') in ['complete','deferred','failed'],'unsettled_transfer')
            transfers.append(directory)
        else: need(not job['resultFile']['exists'] and not job['settledFile']['exists'],'transfer_absence_inconsistent')
    bootstrap_gate(observed,acceptance)
    return [operation['root']['path']]+[job['root']['path'] for job in jobs]+transfers
def main():
    global mutation_started
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--apply',action='store_true');parser.add_argument('--acceptance');parser.add_argument('--receipt')
    args=parser.parse_args();acceptance=read(args.acceptance) if args.acceptance else None
    if args.apply:
        need(acceptance is not None,'explicit_acceptance_required');global_gate(acceptance)
        need(args.receipt and pathlib.Path(args.receipt).is_absolute() and not str(pathlib.Path(args.receipt).resolve()).startswith(str(ROOT)),'external_metadata_receipt_required')
    before=inspect()
    paths=local_gate(before,acceptance) if acceptance else []
    bootstrap_path=str(OLD_BOOTSTRAP) if acceptance and before['oldBootstrap']['exists'] else None
    report={'status':'inspection','applied':False,'observedAt':time.time(),'inspection':before,'candidatePaths':paths+([bootstrap_path] if bootstrap_path else []),'bothFleetGateEvaluated':False}
    if args.apply:
        report['bothFleetGateEvaluated']=True
        pathlib.Path(args.receipt).write_text(json.dumps(report,sort_keys=True)+'\n')
        immediate=inspect();need(local_gate(immediate,acceptance)==paths,'retirement_paths_changed')
        for path in paths:
            info=pathlib.Path(path).lstat();need(stat.S_ISDIR(info.st_mode) and not stat.S_ISLNK(info.st_mode),'retirement_root_not_directory')
        bootstrap_path=bootstrap_gate(immediate,acceptance)
        need(immediate['oldBootstrap']==before['oldBootstrap'],'old_bootstrap_changed')
        mutation_started=True
        for path in paths: shutil.rmtree(path)
        for path in [ROOT/'jobs',ROOT]:
            if path.exists() and not any(path.iterdir()): path.rmdir()
        if bootstrap_path:
            need(old_bootstrap()==immediate['oldBootstrap'],'old_bootstrap_changed')
            OLD_BOOTSTRAP.unlink()
        after=inspect()
        need(after['metadata']['bootId']==before['metadata']['bootId'] and after['gatewayPid']==before['gatewayPid'],'post_cleanup_identity_changed')
        need(after['current']==before['current'] and after['previous']==before['previous'] and after['bootHealthCertified'] is True and after['healthyRuntime']==before['current']['version'] and after['healthyBootStateVersion']==before['current']['version'],'post_cleanup_runtime_changed')
        need(not any(pathlib.Path(path).exists() for path in paths),'retirement_paths_remain')
        need(not after['oldBootstrap']['exists'] and all(after['effectiveWiring'].get(key) is True for key in ['ExecStartPre','ExecStart']),'post_cleanup_bootstrap_changed')
        report.update({'status':'complete','applied':True,'deletedPaths':paths+([bootstrap_path] if bootstrap_path else []),'after':after})
        pathlib.Path(args.receipt).write_text(json.dumps(report,sort_keys=True)+'\n')
    elif args.receipt: pathlib.Path(args.receipt).write_text(json.dumps(report,sort_keys=True)+'\n')
    print(json.dumps(report,sort_keys=True))
if __name__=='__main__':
    try: main()
    except Blocked as error:
        print(json.dumps({'status':'blocked','applied':mutation_started,'reason':str(error)}));raise SystemExit(1)
    except Exception as error:
        print(json.dumps({'status':'blocked','applied':mutation_started,'reason':'inspection_or_operation_failed','errorType':type(error).__name__}));raise SystemExit(1)
