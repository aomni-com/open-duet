import hashlib,json,os,pathlib,stat,subprocess

root=pathlib.Path('/home/synthetic-user/.duet/runtime-adoption')
expected_unit='duet-runtime-adoption.service'
def meta(path):
    path=pathlib.Path(path)
    try:
        item=path.lstat()
        result={'path':str(path),'exists':True,'type':'symlink' if stat.S_ISLNK(item.st_mode) else 'directory' if stat.S_ISDIR(item.st_mode) else 'file' if stat.S_ISREG(item.st_mode) else 'other','mode':stat.S_IMODE(item.st_mode),'uid':item.st_uid,'gid':item.st_gid,'byteLength':item.st_size}
        if stat.S_ISLNK(item.st_mode): result['target']=os.readlink(path)
        return result
    except FileNotFoundError:
        return {'path':str(path),'exists':False}
def read_json(path):
    with pathlib.Path(path).open() as source: return json.load(source)
def picked(value,names): return {key:value[key] for key in names if key in value}
def proc(identity):
    if not identity: return None
    pid=identity.get('pid')
    result={'recordedPid':pid,'recordedStarted':identity.get('started')}
    try:
        fields=pathlib.Path('/proc/'+str(pid)+'/stat').read_text().rpartition(') ')[2].split()
        result.update({'exists':True,'actualStarted':fields[19],'sameIdentity':fields[19]==identity.get('started'),'state':fields[0],'processGroup':int(fields[2])})
    except FileNotFoundError: result['exists']=False
    return result
output={'root':meta(root),'unit':{},'operations':[],'jobs':[],'dropIn':meta('/run/systemd/system/duet-gateway.service.d/duet-runtime-adoption.conf'),'bootId':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'current':meta('/opt/duet/current'),'previous':meta('/opt/duet/previous')}
properties=['LoadState','ActiveState','SubState','MainPID','ControlPID','ControlGroup','Result']
unit=subprocess.run(['systemctl','show',expected_unit,'--property='+','.join(properties)],capture_output=True,text=True,timeout=10)
output['unit']={line.split('=',1)[0]:line.split('=',1)[1] for line in unit.stdout.splitlines() if '=' in line and line.split('=',1)[0] in properties}
output['unitReadExitCode']=unit.returncode
if root.exists():
    children=sorted(root.iterdir(),key=lambda path:path.name)
    if len(children)>100: raise RuntimeError('Unexpected operation count')
    for path in children:
        if path.name=='jobs': continue
        record={'root':meta(path)}
        journal_path=path/'journal.json';record['journal']=meta(journal_path)
        if journal_path.is_file():
            journal=read_json(journal_path)
            record['terminal']=picked(journal,['phase','targetVersion','bootId'])
            record['receipt']=picked(journal.get('receipt',{}),['status','phase','targetVersion','restored','bootIdBefore','bootIdAfter'])
            record['recordedWorker']=proc(journal.get('worker'))
            record['recordedMain']=proc(journal.get('main'))
        record['retainedPaths']=[meta(path/name) for name in ['original','original/snapshot.json','original/releases','original/cli-rail','recovery-releases','staged-releases','staged-current','staged-previous','recovery-current','recovery-previous','census']]
        output['operations'].append(record)
    jobs=root/'jobs'
    if jobs.exists():
        paths=sorted(jobs.iterdir(),key=lambda path:path.name)
        if len(paths)>100: raise RuntimeError('Unexpected job count')
        for path in paths:
            record={'root':meta(path),'descriptor':meta(path/'run.json')}
            if (path/'run.json').is_file():
                run=read_json(path/'run.json')
                record['run']=picked(run,['unit','runId','resultFile','settledFile'])
                record['targetVersion']=run.get('input',{}).get('targetVersion')
                record['runIdMatchesDirectory']=run.get('runId')==path.name
                record['unitMatchesOwner']=run.get('unit')==expected_unit
                for kind in ['resultFile','settledFile']:
                    descriptor=run.get(kind)
                    if not isinstance(descriptor,str) or not descriptor.startswith('/tmp/duet-runtime-adoption-'):
                        record[kind]={'validOwnedPath':False};continue
                    target=pathlib.Path(descriptor)
                    record[kind]=meta(target)
                    record['transferDirectory']=meta(target.parent)
                    if target.is_file():
                        value=read_json(target)
                        record[kind]['observation']=picked(value,['unit','runId','targetVersion','settled','status','phase','restored'])
                record['privateWiring']=[meta(path/name) for name in ['gateway-bun','runtime-bootstrap.js','gateway.service','supervisor.js']]
            output['jobs'].append(record)
print(json.dumps(output,sort_keys=True))
